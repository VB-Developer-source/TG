import { useState } from "react";
import { AudioManager, DEFAULT_AUDIO, type AudioSettings } from "@/audio/AudioManager";
import { playBrake, playDoorBuzzer, playDoorClose, playDoorOpen, playHorn, stopAllLoops, toggleLoop, type LoopId } from "@/audio/TrainAudio";
import { LIVERIES, LIVERY_ORDER } from "@/train/TrainConfig";
import { useTrainStore, type LightState, type ViewId } from "@/train/store";

const VIEW_LIST: { id: ViewId; label: string }[] = [
  { id: "front", label: "Front" },
  { id: "rear", label: "Rear" },
  { id: "side", label: "Side" },
  { id: "full", label: "Full rake" },
  { id: "bogie", label: "Bogie" },
  { id: "pantograph", label: "Pantograph" },
  { id: "coupling", label: "Coupling" },
  { id: "interior", label: "Interior" },
  { id: "cab", label: "Driver cab" },
];

const LIGHT_LIST: { id: keyof LightState; label: string }[] = [
  { id: "headlights", label: "Headlights" },
  { id: "tail", label: "Tail lights" },
  { id: "interior", label: "Interior" },
  { id: "destination", label: "Destination" },
];

function Slider({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="flex items-center gap-3 text-xs">
      <span className="w-14 text-muted-foreground">{label}</span>
      <input
        type="range"
        min={0}
        max={1}
        step={0.01}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="range-signage flex-1"
      />
      <span className="w-8 text-right font-mono">{Math.round(value * 100)}</span>
    </label>
  );
}

function AudioPanel() {
  const [s, setS] = useState<AudioSettings>(DEFAULT_AUDIO);
  const [loops, setLoops] = useState<Record<LoopId, boolean>>({ motor: false, rolling: false, clatter: false });
  const update = (p: Partial<AudioSettings>) => {
    AudioManager.unlock();
    const next = { ...s, ...p };
    setS(next);
    AudioManager.setSettings(next);
  };
  const loop = (id: LoopId) => setLoops((l) => ({ ...l, [id]: toggleLoop(id) }));
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <button className="btn-signage-primary col-span-2" onClick={() => playHorn()}>
          Horn
        </button>
        {(["motor", "rolling", "clatter"] as LoopId[]).map((id) => (
          <button key={id} className="btn-chip" data-active={loops[id]} onClick={() => loop(id)}>
            {id === "motor" ? "Motor hum" : id === "rolling" ? "Wheel rolling" : "Track clatter"}
          </button>
        ))}
        <button className="btn-chip" onClick={() => playBrake()}>
          Brakes
        </button>
        <button className="btn-chip" onClick={() => playDoorBuzzer()}>
          Door buzzer
        </button>
        <button
          className="btn-chip"
          onClick={() => {
            stopAllLoops();
            setLoops({ motor: false, rolling: false, clatter: false });
          }}
        >
          Stop loops
        </button>
      </div>
      <Slider label="Master" value={s.master} onChange={(v) => update({ master: v })} />
      <Slider label="Train" value={s.train} onChange={(v) => update({ train: v })} />
      <Slider label="SFX" value={s.sfx} onChange={(v) => update({ sfx: v })} />
      <button className="btn-chip w-full" data-active={s.muted} onClick={() => update({ muted: !s.muted })}>
        {s.muted ? "Unmute" : "Mute all"}
      </button>
    </div>
  );
}

export function TrainPreviewUI() {
  const { view, setView, lights, toggleLight, doorsOpen, setDoorsOpen, livery, setLivery, setScreen, wheelDemo, setWheelDemo } =
    useTrainStore();
  const [tab, setTab] = useState<"lights" | "audio">("lights");
  const l = LIVERIES[livery];

  const toggleDoors = () => {
    const open = !doorsOpen;
    if (open) playDoorOpen();
    else {
      playDoorBuzzer();
      playDoorClose();
    }
    setDoorsOpen(open);
  };

  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col p-3 md:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="pointer-events-auto hud-panel px-4 py-3">
          <p className="signage-kicker">{l.terminals}</p>
          <h2 className="signage-heading">
            {l.name} <span className="font-mono text-sm text-primary">{l.trainNumber}</span>
          </h2>
          <div className="mt-2 flex gap-1">
            {LIVERY_ORDER.map((id) => (
              <button key={id} className="btn-chip" data-active={id === livery} onClick={() => setLivery(id)}>
                {LIVERIES[id].short}
              </button>
            ))}
          </div>
        </div>
        <div className="pointer-events-auto flex gap-2">
          <button className="btn-signage-ghost" onClick={() => setScreen("select")}>
            ← Train select
          </button>
          <button className="btn-signage-ghost" onClick={() => setScreen("menu")}>
            Menu
          </button>
        </div>
      </div>

      <div className="mt-auto flex flex-col-reverse gap-3 md:flex-row md:items-end md:justify-between">
        <div className="pointer-events-auto hud-panel p-3">
          <p className="signage-kicker mb-2">Camera</p>
          <div className="grid grid-cols-3 gap-1.5 md:grid-cols-3">
            {VIEW_LIST.map((v) => (
              <button key={v.id} className="btn-chip" data-active={v.id === view} onClick={() => setView(v.id)}>
                {v.label}
              </button>
            ))}
          </div>
          <p className="mt-2 text-[11px] text-muted-foreground">Drag to rotate · scroll or pinch to zoom</p>
        </div>

        <div className="pointer-events-auto hud-panel w-full p-3 md:w-72">
          <div className="mb-3 flex gap-1">
            {(["lights", "audio"] as const).map((t) => (
              <button key={t} className="btn-chip flex-1 capitalize" data-active={tab === t} onClick={() => setTab(t)}>
                {t === "lights" ? "Lights & doors" : "Audio"}
              </button>
            ))}
          </div>
          {tab === "lights" ? (
            <div className="grid grid-cols-2 gap-1.5">
              {LIGHT_LIST.map((x) => (
                <button key={x.id} className="btn-chip" data-active={lights[x.id]} onClick={() => toggleLight(x.id)}>
                  {x.label} {lights[x.id] ? "on" : "off"}
                </button>
              ))}
              <button className="btn-signage-primary col-span-2" onClick={toggleDoors}>
                {doorsOpen ? "Close doors" : "Open doors"}
              </button>
              <button className="btn-chip col-span-2" data-active={wheelDemo} onClick={() => setWheelDemo(!wheelDemo)}>
                Wheel spin demo {wheelDemo ? "on" : "off"}
              </button>
            </div>
          ) : (
            <AudioPanel />
          )}
        </div>
      </div>
    </div>
  );
}
