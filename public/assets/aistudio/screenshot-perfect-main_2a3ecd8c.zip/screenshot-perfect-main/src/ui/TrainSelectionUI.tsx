import { AudioManager } from "@/audio/AudioManager";
import { LIVERIES, LIVERY_ORDER } from "@/train/TrainConfig";
import { useTrainStore } from "@/train/store";

export function MainMenu() {
  const setScreen = useTrainStore((s) => s.setScreen);
  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-6 md:p-10">
      <div className="pointer-events-auto max-w-xl">
        <p className="signage-kicker">Mumbai Suburban · 12-car EMU</p>
        <h1 className="signage-title mt-2">
          Mumbai Local
          <span className="block text-primary">Train Simulator 3D</span>
        </h1>
      </div>
      <div className="pointer-events-auto flex w-full max-w-xs flex-col gap-3">
        <button
          className="btn-signage-primary"
          onClick={() => {
            AudioManager.unlock();
            setScreen("select");
          }}
        >
          Train Select
        </button>
        <button className="btn-signage" disabled title="Coming in a later section">
          Drive (coming soon)
        </button>
      </div>
    </div>
  );
}

export function TrainSelection() {
  const { livery, setLivery, setScreen } = useTrainStore();
  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col justify-end p-4 md:p-8">
      <div className="pointer-events-auto hud-panel mx-auto w-full max-w-4xl p-5">
        <div className="flex items-center justify-between">
          <h2 className="signage-heading">Train Select</h2>
          <button className="btn-signage-ghost" onClick={() => setScreen("menu")}>
            ← Main menu
          </button>
        </div>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          {LIVERY_ORDER.map((id) => {
            const l = LIVERIES[id];
            const active = id === livery;
            return (
              <button
                key={id}
                onClick={() => setLivery(id)}
                className="livery-card"
                data-active={active}
                aria-pressed={active}
              >
                <div className="flex h-3 overflow-hidden rounded-sm">
                  <span className="flex-[3]" style={{ background: l.body }} />
                  <span className="flex-1" style={{ background: l.band }} />
                  <span className="flex-1" style={{ background: l.front }} />
                </div>
                <div className="mt-3 flex items-baseline justify-between">
                  <span className="signage-heading text-xl">{l.name}</span>
                  <span className="font-mono text-xs text-muted-foreground">{l.short}</span>
                </div>
                <p className="mt-1 font-mono text-xs text-primary">
                  {l.routeCode} · {l.destination} · {l.trainNumber}
                </p>
                <p className="mt-2 text-sm text-muted-foreground">{l.description}</p>
              </button>
            );
          })}
        </div>
        <div className="mt-4 flex justify-end">
          <button className="btn-signage-primary" onClick={() => setScreen("preview")}>
            Inspect {LIVERIES[livery].name} →
          </button>
        </div>
      </div>
    </div>
  );
}
