import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { ballastTexture, concreteTexture } from "@/train/textures";
import { RAIL_HALF_GAUGE } from "@/train/TrainConfig";

const LEN = 300;

function Instanced({ geo, mat, items }: { geo: THREE.BufferGeometry; mat: THREE.Material; items: THREE.Matrix4[] }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  useLayoutEffect(() => {
    items.forEach((m, i) => ref.current!.setMatrixAt(i, m));
    ref.current!.instanceMatrix.needsUpdate = true;
  }, [items]);
  return <instancedMesh ref={ref} args={[geo, mat, items.length]} receiveShadow castShadow frustumCulled={false} />;
}

const mk = (p: [number, number, number], s: [number, number, number]) =>
  new THREE.Matrix4().compose(new THREE.Vector3(...p), new THREE.Quaternion(), new THREE.Vector3(...s));

/** Static display siding + platform so the rake has something to stand on (no route system). */
export function DisplayYard() {
  const res = useMemo(() => {
    const box = new THREE.BoxGeometry(1, 1, 1);
    const ballast = new THREE.MeshStandardMaterial({ map: ballastTexture(), roughness: 1 });
    const concrete = new THREE.MeshStandardMaterial({ map: concreteTexture(), roughness: 0.9 });
    const rail = new THREE.MeshStandardMaterial({ color: "#8c9196", roughness: 0.3, metalness: 0.9 });
    const sleeper = new THREE.MeshStandardMaterial({ color: "#8a857c", roughness: 0.95 });
    const yellow = new THREE.MeshStandardMaterial({ color: "#efbd12", roughness: 0.6 });
    const steel = new THREE.MeshStandardMaterial({ color: "#3f5560", roughness: 0.5, metalness: 0.6 });
    const roof = new THREE.MeshStandardMaterial({ color: "#6f7b80", roughness: 0.6, metalness: 0.5, side: THREE.DoubleSide });
    const ground = new THREE.MeshStandardMaterial({ color: "#7d7262", roughness: 1 });
    const sleepers: THREE.Matrix4[] = [];
    for (let z = -LEN / 2; z < LEN / 2; z += 0.65) sleepers.push(mk([0, -0.1, z], [2.75, 0.18, 0.26]));
    const rails = [1, -1].flatMap((s) => [
      mk([s * RAIL_HALF_GAUGE, 0.0 - 0.04, 0], [0.07, 0.08, LEN]),
      mk([s * RAIL_HALF_GAUGE, -0.12, 0], [0.02, 0.12, LEN]),
      mk([s * RAIL_HALF_GAUGE, -0.17, 0], [0.14, 0.02, LEN]),
    ]);
    const columns: THREE.Matrix4[] = [];
    for (let z = -120; z <= 130; z += 12) columns.push(mk([-6.5, 3.6, z], [0.25, 5.4, 0.25]));
    return { box, ballast, concrete, rail, sleeper, yellow, steel, roof, ground, sleepers, rails, columns };
  }, []);

  return (
    <group>
      <mesh geometry={res.box} material={res.ground} position={[0, -0.62, 0]} scale={[400, 0.2, LEN + 200]} receiveShadow />
      <mesh geometry={res.box} material={res.ballast} position={[0, -0.36, 0]} scale={[4.2, 0.36, LEN]} receiveShadow />
      <Instanced geo={res.box} mat={res.sleeper} items={res.sleepers} />
      <Instanced geo={res.box} mat={res.rail} items={res.rails} />
      {/* platform (Mumbai platforms sit close to floor height) */}
      <mesh geometry={res.box} material={res.concrete} position={[-5.6, 0.2, 0]} scale={[7, 1.5, LEN]} receiveShadow castShadow />
      <mesh geometry={res.box} material={res.yellow} position={[-2.3, 0.955, 0]} scale={[0.3, 0.012, LEN]} />
      <Instanced geo={res.box} mat={res.steel} items={res.columns} />
      <mesh geometry={res.box} material={res.roof} position={[-6.2, 6.4, 5]} scale={[6.5, 0.12, 252]} rotation={[0, 0, 0.08]} castShadow />
    </group>
  );
}
