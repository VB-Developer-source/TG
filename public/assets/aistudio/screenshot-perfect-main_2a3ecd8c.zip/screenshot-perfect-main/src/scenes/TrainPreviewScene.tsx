import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer, OrbitControls, Sky } from "@react-three/drei";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { Train } from "@/train/Train";
import { DisplayYard } from "./DisplayYard";
import { coachZ, COACH_LENGTH, FRONT_FACE_Z, PANTOGRAPH_Z, REAR_FACE_Z, BOGIE_OFFSET } from "@/train/TrainConfig";
import { useTrainStore, type ViewId } from "@/train/store";

type V3 = [number, number, number];
const z0 = coachZ(0);
const z1 = coachZ(1);

export const VIEWS: Record<ViewId, { pos: V3; target: V3; min?: number }> = {
  menu: { pos: [13, 4.2, FRONT_FACE_Z + 13], target: [0, 2.2, FRONT_FACE_Z - 8] },
  full: { pos: [95, 38, 70], target: [0, 2, 10] },
  front: { pos: [5.5, 2.6, FRONT_FACE_Z + 10], target: [0, 2.4, FRONT_FACE_Z] },
  rear: { pos: [6, 2.8, REAR_FACE_Z - 11], target: [0, 2.4, REAR_FACE_Z] },
  side: { pos: [13, 2.4, z0 - 3], target: [0, 2.3, z0 - 3] },
  bogie: { pos: [3.6, 0.9, z0 + BOGIE_OFFSET + 2.6], target: [0.6, 0.6, z0 + BOGIE_OFFSET] },
  pantograph: { pos: [6.5, 7.2, z1 + PANTOGRAPH_Z + 6], target: [0, 4.8, z1 + PANTOGRAPH_Z] },
  coupling: { pos: [3.2, 2.2, z0 - COACH_LENGTH / 2 - 3], target: [0, 1.6, z0 - COACH_LENGTH / 2 - 0.35] },
  interior: { pos: [0.3, 2.85, z1 + 8.5], target: [0, 2.6, z1 + 2], min: 0.05 },
  cab: { pos: [0.72, 2.95, FRONT_FACE_Z - 1.55], target: [0.6, 2.55, FRONT_FACE_Z + 0.6], min: 0.05 },
};

const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

function CameraRig() {
  const view = useTrainStore((s) => s.view);
  const screen = useTrainStore((s) => s.screen);
  const camera = useThree((s) => s.camera);
  const controls = useThree((s) => s.controls) as unknown as OrbitControlsImpl | null;
  const anim = useRef({ active: false, t: 0, fromP: new THREE.Vector3(), fromT: new THREE.Vector3() });
  const to = useMemo(() => ({ p: new THREE.Vector3(...VIEWS[view].pos), t: new THREE.Vector3(...VIEWS[view].target) }), [view]);

  const skip = useRef(true);
  useEffect(() => {
    if (!controls) return;
    if (skip.current) {
      camera.position.set(...VIEWS[view].pos);
      controls.target.set(...VIEWS[view].target);
      controls.update();
      skip.current = false;
      controls.minDistance = VIEWS[view].min ?? 1.5;
      return;
    }
    anim.current = { active: true, t: 0, fromP: camera.position.clone(), fromT: controls.target.clone() };
    controls.minDistance = VIEWS[view].min ?? 1.5;
  }, [view, controls, camera]);

  useEffect(() => {
    if (controls) controls.autoRotate = screen !== "preview";
  }, [screen, controls]);

  useFrame((_, delta) => {
    const a = anim.current;
    if (!a.active || !controls) return;
    a.t = Math.min(1, a.t + Math.min(delta, 0.05) / 1.6);
    const e = ease(a.t);
    camera.position.lerpVectors(a.fromP, to.p, e);
    controls.target.lerpVectors(a.fromT, to.t, e);
    controls.update();
    if (a.t >= 1) a.active = false;
  });
  return null;
}

function ReadySignal({ onReady }: { onReady: () => void }) {
  const frames = useRef(0);
  useFrame(() => {
    frames.current++;
    if (frames.current === 3) onReady();
  });
  return null;
}

export function TrainPreviewScene() {
  const [ready, setReady] = useState(false);
  return (
    <div className="absolute inset-0" data-scene-ready={ready ? "true" : undefined}>
      <Canvas
        shadows
        dpr={[1, 2]}
        camera={{ position: VIEWS.menu.pos, fov: 45, near: 0.05, far: 1200 }}
        gl={{ antialias: true }}
      >
        <color attach="background" args={["#cfc6b4"]} />
        <fog attach="fog" args={["#d4cab6", 120, 520]} />
        <Sky sunPosition={[80, 30, 60]} turbidity={9} rayleigh={1.6} mieCoefficient={0.01} />
        <hemisphereLight args={["#dfe6ee", "#6b5a45", 0.9]} />
        <directionalLight
          position={[40, 55, 25]}
          intensity={2.6}
          color="#ffe9c9"
          castShadow
          shadow-mapSize={[4096, 4096]}
          shadow-camera-left={-150}
          shadow-camera-right={150}
          shadow-camera-top={150}
          shadow-camera-bottom={-150}
          shadow-camera-far={300}
          shadow-bias={-0.0004}
          shadow-normalBias={0.04}
        />
        <Environment resolution={256}>
          <Lightformer intensity={2} position={[0, 10, 0]} scale={[30, 30, 1]} rotation-x={Math.PI / 2} />
          <Lightformer intensity={1.2} color="#ffd9a8" position={[-10, 3, 0]} rotation-y={Math.PI / 2} scale={[40, 3, 1]} />
          <Lightformer intensity={0.8} color="#a8c4ff" position={[10, 3, 0]} rotation-y={-Math.PI / 2} scale={[40, 3, 1]} />
        </Environment>
        <DisplayYard />
        <Train />
        <OrbitControls makeDefault enableDamping dampingFactor={0.08} autoRotateSpeed={0.35} maxDistance={320} maxPolarAngle={Math.PI * 0.62} />
        <CameraRig />
        <ReadySignal onReady={() => setReady(true)} />
      </Canvas>
    </div>
  );
}
