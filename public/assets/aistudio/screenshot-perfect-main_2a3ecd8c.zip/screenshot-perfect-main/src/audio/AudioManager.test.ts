import { describe, expect, it } from "vitest";
import { DEFAULT_AUDIO, effectiveGain } from "./AudioManager";

describe("audio bus gains", () => {
  it("mute silences every bus", () => {
    expect(effectiveGain({ ...DEFAULT_AUDIO, muted: true }, "train")).toBe(0);
    expect(effectiveGain({ ...DEFAULT_AUDIO, muted: true }, "sfx")).toBe(0);
  });
  it("master volume scales the train and sfx buses", () => {
    expect(effectiveGain({ master: 0.5, train: 0.8, sfx: 0.4, muted: false }, "train")).toBeCloseTo(0.4);
    expect(effectiveGain({ master: 0.5, train: 0.8, sfx: 0.4, muted: false }, "sfx")).toBeCloseTo(0.2);
  });
});
