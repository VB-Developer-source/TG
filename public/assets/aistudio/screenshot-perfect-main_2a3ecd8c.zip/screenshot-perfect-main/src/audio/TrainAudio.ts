// Original synthesized EMU sounds. Loops expose setSpeed() so future
// train physics can drive pitch/level from trainRuntime.speed.
import { AudioManager } from "./AudioManager";

export type LoopId = "motor" | "rolling" | "clatter";

interface LoopHandle {
  stop: () => void;
  setSpeed: (kmh: number) => void;
}

const loops = new Map<LoopId, LoopHandle>();
const PREVIEW_SPEED = 45;

function env(g: GainNode, t: number, a: number, peak: number, hold: number, r: number) {
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + a);
  g.gain.setValueAtTime(peak, t + a + hold);
  g.gain.exponentialRampToValueAtTime(0.0001, t + a + hold + r);
}

function noiseSource() {
  const ctx = AudioManager.unlock();
  const src = ctx.createBufferSource();
  src.buffer = AudioManager.noiseBuffer();
  src.loop = true;
  return src;
}

/** Two-tone EMU horn. */
export function playHorn(duration = 1.1) {
  const ctx = AudioManager.unlock();
  const t = ctx.currentTime;
  const out = ctx.createGain();
  env(out, t, 0.04, 0.35, duration, 0.25);
  const lp = ctx.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.value = 2400;
  lp.Q.value = 2;
  lp.connect(out).connect(AudioManager.bus("train"));
  for (const f of [311, 370, 622]) {
    const o = ctx.createOscillator();
    o.type = "sawtooth";
    o.frequency.setValueAtTime(f * 0.97, t);
    o.frequency.linearRampToValueAtTime(f, t + 0.08);
    const g = ctx.createGain();
    g.gain.value = f > 600 ? 0.15 : 0.5;
    o.connect(g).connect(lp);
    o.start(t);
    o.stop(t + duration + 0.4);
  }
}

export function playBrake() {
  const ctx = AudioManager.unlock();
  const t = ctx.currentTime;
  const bus = AudioManager.bus("train");
  const squeal = ctx.createOscillator();
  squeal.frequency.setValueAtTime(3100, t);
  squeal.frequency.linearRampToValueAtTime(2700, t + 2.2);
  const sg = ctx.createGain();
  env(sg, t, 0.3, 0.05, 1.4, 0.6);
  squeal.connect(sg).connect(bus);
  squeal.start(t);
  squeal.stop(t + 2.6);
  const n = noiseSource();
  const bp = ctx.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = 900;
  const ng = ctx.createGain();
  env(ng, t, 0.2, 0.25, 1.4, 0.5);
  n.connect(bp).connect(ng).connect(bus);
  n.start(t);
  n.stop(t + 2.4);
  // air release hiss
  const h = noiseSource();
  const hp = ctx.createBiquadFilter();
  hp.type = "highpass";
  hp.frequency.value = 3500;
  const hg = ctx.createGain();
  env(hg, t + 2.2, 0.02, 0.22, 0.3, 0.7);
  h.connect(hp).connect(hg).connect(bus);
  h.start(t + 2.1);
  h.stop(t + 3.4);
}

export function playDoorBuzzer() {
  const ctx = AudioManager.unlock();
  const t = ctx.currentTime;
  for (let i = 0; i < 5; i++) {
    const o = ctx.createOscillator();
    o.type = "square";
    o.frequency.value = 760;
    const g = ctx.createGain();
    env(g, t + i * 0.4, 0.01, 0.12, 0.22, 0.03);
    o.connect(g).connect(AudioManager.bus("sfx"));
    o.start(t + i * 0.4);
    o.stop(t + i * 0.4 + 0.3);
  }
}

function doorMove(closing: boolean) {
  const ctx = AudioManager.unlock();
  const t = ctx.currentTime;
  const bus = AudioManager.bus("sfx");
  const n = noiseSource();
  const lp = ctx.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.setValueAtTime(closing ? 1400 : 600, t);
  lp.frequency.linearRampToValueAtTime(closing ? 500 : 1500, t + 1.4);
  const g = ctx.createGain();
  env(g, t, 0.1, 0.3, 1.1, 0.25);
  n.connect(lp).connect(g).connect(bus);
  n.start(t);
  n.stop(t + 1.6);
  // pneumatic hiss at start
  const h = noiseSource();
  const hp = ctx.createBiquadFilter();
  hp.type = "highpass";
  hp.frequency.value = 4000;
  const hg = ctx.createGain();
  env(hg, t, 0.01, 0.12, 0.15, 0.3);
  h.connect(hp).connect(hg).connect(bus);
  h.start(t);
  h.stop(t + 0.6);
  // end thump
  const o = ctx.createOscillator();
  o.frequency.setValueAtTime(closing ? 110 : 80, t + 1.45);
  o.frequency.exponentialRampToValueAtTime(40, t + 1.75);
  const og = ctx.createGain();
  env(og, t + 1.45, 0.005, closing ? 0.6 : 0.3, 0.02, 0.25);
  o.connect(og).connect(bus);
  o.start(t + 1.4);
  o.stop(t + 1.9);
}

export const playDoorOpen = () => doorMove(false);
export const playDoorClose = () => doorMove(true);

function startMotor(): LoopHandle {
  const ctx = AudioManager.unlock();
  const out = ctx.createGain();
  out.gain.value = 0;
  out.gain.setTargetAtTime(0.18, ctx.currentTime, 0.3);
  out.connect(AudioManager.bus("train"));
  const lp = ctx.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.value = 900;
  lp.connect(out);
  const base = ctx.createOscillator();
  base.type = "sawtooth";
  const whine = ctx.createOscillator();
  whine.type = "sine";
  const wg = ctx.createGain();
  wg.gain.value = 0.25;
  const lfo = ctx.createOscillator();
  lfo.frequency.value = 6;
  const lg = ctx.createGain();
  lg.gain.value = 3;
  lfo.connect(lg).connect(base.frequency);
  base.connect(lp);
  whine.connect(wg).connect(out);
  [base, whine, lfo].forEach((o) => o.start());
  const setSpeed = (kmh: number) => {
    const t = ctx.currentTime;
    base.frequency.setTargetAtTime(70 + kmh * 2.2, t, 0.2);
    whine.frequency.setTargetAtTime(400 + kmh * 18, t, 0.2);
  };
  setSpeed(PREVIEW_SPEED);
  return {
    setSpeed,
    stop: () => {
      out.gain.setTargetAtTime(0, ctx.currentTime, 0.2);
      [base, whine, lfo].forEach((o) => o.stop(ctx.currentTime + 1));
    },
  };
}

function startRolling(): LoopHandle {
  const ctx = AudioManager.unlock();
  const n = noiseSource();
  const lp = ctx.createBiquadFilter();
  lp.type = "lowpass";
  const out = ctx.createGain();
  out.gain.value = 0;
  n.connect(lp).connect(out).connect(AudioManager.bus("train"));
  n.start();
  const setSpeed = (kmh: number) => {
    const t = ctx.currentTime;
    lp.frequency.setTargetAtTime(150 + kmh * 8, t, 0.2);
    out.gain.setTargetAtTime(Math.min(0.5, 0.05 + kmh / 200), t, 0.3);
  };
  setSpeed(PREVIEW_SPEED);
  return {
    setSpeed,
    stop: () => {
      out.gain.setTargetAtTime(0, ctx.currentTime, 0.2);
      n.stop(ctx.currentTime + 1);
    },
  };
}

function startClatter(): LoopHandle {
  const ctx = AudioManager.unlock();
  let kmh = PREVIEW_SPEED;
  let timer = 0;
  const click = (at: number) => {
    const n = ctx.createBufferSource();
    n.buffer = AudioManager.noiseBuffer();
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 260;
    bp.Q.value = 1.4;
    const g = ctx.createGain();
    env(g, at, 0.002, 0.7, 0.01, 0.09);
    n.connect(bp).connect(g).connect(AudioManager.bus("train"));
    n.start(at, Math.random());
    n.stop(at + 0.15);
  };
  const tick = () => {
    const mps = Math.max(kmh, 5) / 3.6;
    const t = ctx.currentTime + 0.02;
    const axleGap = 2.6 / mps; // wheelbase
    click(t);
    click(t + axleGap);
    timer = window.setTimeout(tick, (13 / mps) * 1000); // rail joint spacing
  };
  tick();
  return { setSpeed: (v) => (kmh = v), stop: () => window.clearTimeout(timer) };
}

const STARTERS: Record<LoopId, () => LoopHandle> = { motor: startMotor, rolling: startRolling, clatter: startClatter };

export function toggleLoop(id: LoopId): boolean {
  const cur = loops.get(id);
  if (cur) {
    cur.stop();
    loops.delete(id);
    return false;
  }
  loops.set(id, STARTERS[id]());
  return true;
}

export function stopAllLoops() {
  loops.forEach((l) => l.stop());
  loops.clear();
}

/** Hook for future physics. */
export function setTrainSpeed(kmh: number) {
  loops.forEach((l) => l.setSpeed(kmh));
}
