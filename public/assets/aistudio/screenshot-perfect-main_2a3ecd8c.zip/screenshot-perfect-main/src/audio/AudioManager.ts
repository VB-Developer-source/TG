// Bus-based Web Audio manager. Context is created on the first user gesture
// (browser autoplay policy). Buses: master -> { train, sfx }.

export type Bus = "master" | "train" | "sfx";

export interface AudioSettings {
  master: number;
  train: number;
  sfx: number;
  muted: boolean;
}

export const DEFAULT_AUDIO: AudioSettings = { master: 0.8, train: 0.8, sfx: 0.8, muted: false };

/** Effective linear gain of a bus given the settings (master applies to all). */
export function effectiveGain(s: AudioSettings, bus: Exclude<Bus, "master">) {
  if (s.muted) return 0;
  return s.master * s[bus];
}

class AudioManagerImpl {
  ctx: AudioContext | null = null;
  private master!: GainNode;
  private buses!: Record<"train" | "sfx", GainNode>;
  private noise: AudioBuffer | null = null;
  settings: AudioSettings = { ...DEFAULT_AUDIO };

  /** Call from a click/tap handler. */
  unlock() {
    if (!this.ctx) {
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new Ctx();
      this.master = this.ctx.createGain();
      const comp = this.ctx.createDynamicsCompressor();
      this.master.connect(comp).connect(this.ctx.destination);
      this.buses = { train: this.ctx.createGain(), sfx: this.ctx.createGain() };
      this.buses.train.connect(this.master);
      this.buses.sfx.connect(this.master);
      this.apply();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  get ready() {
    return !!this.ctx;
  }

  setSettings(s: Partial<AudioSettings>) {
    this.settings = { ...this.settings, ...s };
    this.apply();
  }

  private apply() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.settings.muted ? 0 : this.settings.master, t, 0.03);
    this.buses.train.gain.setTargetAtTime(this.settings.train, t, 0.03);
    this.buses.sfx.gain.setTargetAtTime(this.settings.sfx, t, 0.03);
  }

  bus(name: "train" | "sfx") {
    this.unlock();
    return this.buses[name];
  }

  noiseBuffer() {
    const ctx = this.unlock();
    if (!this.noise) {
      const len = ctx.sampleRate * 2;
      this.noise = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = this.noise.getChannelData(0);
      let b = 0;
      for (let i = 0; i < len; i++) {
        const w = Math.random() * 2 - 1;
        b = 0.97 * b + 0.03 * w; // mix of white + brown
        d[i] = w * 0.5 + b * 3;
      }
    }
    return this.noise;
  }
}

export const AudioManager = new AudioManagerImpl();
