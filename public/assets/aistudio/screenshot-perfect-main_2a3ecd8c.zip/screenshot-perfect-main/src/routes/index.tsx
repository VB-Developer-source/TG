import { createFileRoute } from "@tanstack/react-router";
import { TrainPreviewScene } from "@/scenes/TrainPreviewScene";
import { MainMenu, TrainSelection } from "@/ui/TrainSelectionUI";
import { TrainPreviewUI } from "@/ui/TrainPreviewUI";
import { useTrainStore } from "@/train/store";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Mumbai Local Train Simulator 3D — Train Select" },
      {
        name: "description",
        content: "Inspect a detailed 12-coach Mumbai suburban EMU in 3D: cab, interior, bogies, pantograph, liveries, lights and sounds.",
      },
      { property: "og:title", content: "Mumbai Local Train Simulator 3D" },
      { property: "og:description", content: "Inspect a detailed 12-coach Mumbai suburban local train in your browser." },
    ],
  }),
  component: Game,
});

function Game() {
  const screen = useTrainStore((s) => s.screen);
  return (
    <main className="fixed inset-0 overflow-hidden bg-background text-foreground">
      <TrainPreviewScene />
      {screen === "menu" && <div className="menu-vignette pointer-events-none absolute inset-0" />}
      {screen === "menu" && <MainMenu />}
      {screen === "select" && <TrainSelection />}
      {screen === "preview" && <TrainPreviewUI />}
    </main>
  );
}
