import { describe, expect, it } from "vitest";
import { buildTrainLayout, COACH_LENGTH, LIVERIES } from "./TrainConfig";

const layout = buildTrainLayout(LIVERIES.western);

describe("12-coach train layout", () => {
  it("has exactly 12 coaches", () => {
    expect(layout).toHaveLength(12);
  });

  it("has driving cabs only at both ends, rear one flipped", () => {
    expect(layout[0]!.role).toBe("cab-front");
    expect(layout[11]!.role).toBe("cab-rear");
    expect(layout[11]!.flipped).toBe(true);
    expect(layout.filter((c) => c.cab)).toHaveLength(2);
  });

  it("spaces coaches without overlap and with a small gap", () => {
    for (let i = 1; i < layout.length; i++) {
      const gap = layout[i - 1]!.z - layout[i]!.z - COACH_LENGTH;
      expect(gap).toBeGreaterThan(0);
      expect(gap).toBeLessThan(1.5);
    }
  });

  it("has four motor coaches carrying pantographs", () => {
    expect(layout.filter((c) => c.motor)).toHaveLength(4);
  });
});
