import * as THREE from "three";
import { PartBuilder, type V3 } from "./PartBuilder";
import {
  BOGIE_OFFSET,
  CAB_DEPTH,
  COACH_LENGTH,
  DOOR_Z,
  PANTOGRAPH_Z,
  RAIL_HALF_GAUGE,
  WHEEL_RADIUS,
  WINDOW_Z,
  type CoachSpec,
} from "./TrainConfig";
import { WINDSHIELD } from "./geometries";

const HL = COACH_LENGTH / 2;
const SIDES = [1, -1] as const;

export interface DoorLeafSlot {
  coach: THREE.Matrix4;
  side: number;
  z: number;
  dir: number;
}
export interface AxleSlot {
  matrix: THREE.Matrix4;
}

export interface TrainParts {
  builder: PartBuilder;
  leaves: DoorLeafSlot[];
  axles: AxleSlot[];
  coachMatrices: THREE.Matrix4[];
}

export function coachMatrix(c: CoachSpec) {
  const m = new THREE.Matrix4().makeTranslation(0, 0, c.z);
  if (c.flipped) m.multiply(new THREE.Matrix4().makeRotationY(Math.PI));
  return m;
}

/** Build every static part of the 12-coach rake into shared instanced batches. */
export function buildTrain(layout: CoachSpec[]): TrainParts {
  const b = new PartBuilder();
  const leaves: DoorLeafSlot[] = [];
  const axles: AxleSlot[] = [];
  const coachMatrices: THREE.Matrix4[] = [];

  for (const c of layout) {
    const cm = coachMatrix(c);
    coachMatrices.push(cm);
    b.within(cm, () => {
      buildShell(b, c);
      buildSides(b, c);
      for (const side of SIDES)
        for (const z of DOOR_Z) for (const dir of [1, -1]) leaves.push({ coach: cm, side, z, dir });
      buildInterior(b, c);
      buildRoof(b, c);
      buildUnderframe(b, c);
      for (const bz of [BOGIE_OFFSET, -BOGIE_OFFSET]) {
        b.translated([0, 0, bz], () => buildBogie(b, c.motor));
        for (const az of [1.3, -1.3]) {
          axles.push({ matrix: cm.clone().multiply(new THREE.Matrix4().makeTranslation(0, WHEEL_RADIUS, bz + az)) });
        }
      }
      if (c.cab) buildCab(b, c.role === "cab-front");
      buildEnd(b, -1);
      if (!c.cab) buildEnd(b, 1);
    });
  }
  return { builder: b, leaves, axles, coachMatrices };
}

function buildShell(b: PartBuilder, c: CoachSpec) {
  b.add("body", "body", [0, 0, 0]);
  b.add("endplate", "body", [0, 0, -HL], [1, 1, 1], [0, Math.PI, 0]);
  if (c.cab) b.add("endplateCab", "front", [0, 0, HL]);
  else b.add("endplateGangway", "body", [0, 0, HL]);
  // body-side belt lines
  for (const s of SIDES) {
    b.box("band", [s * 1.836, 1.74, 0], [0.012, 0.52, COACH_LENGTH - 0.02]);
    b.box("bandThin", [s * 1.836, 3.33, 0], [0.012, 0.16, COACH_LENGTH - 0.02]);
    // rain gutter
    b.cyl("frame", [s * 1.7, 3.84, 0], 0.025, COACH_LENGTH, [Math.PI / 2, 0, 0], "cylLow");
  }
  // cab front colour wraps onto the sides
  if (c.cab) {
    for (const s of SIDES) b.box("front", [s * 1.834, 2.5, HL - 0.6], [0.012, 2.8, 1.2]);
  }
}

function buildSides(b: PartBuilder, c: CoachSpec) {
  const windows = c.cab ? WINDOW_Z.filter((z) => z < HL - CAB_DEPTH) : WINDOW_Z;
  for (const s of SIDES) {
    for (const z of windows) {
      b.box("frame", [s * 1.838, 2.55, z], [0.012, 1.06, 1.22]);
      b.box("winOut", [s * 1.844, 2.55, z], [0.01, 0.95, 1.1]);
      b.box("winIn", [s * 1.728, 2.55, z], [0.01, 0.95, 1.1]);
    }
    for (const z of DOOR_Z) {
      b.box("doorway", [s * 1.846, 2.225, z], [0.01, 2.05, 1.36]);
      for (const e of [1, -1]) {
        b.box("yellow", [s * 1.852, 2.225, z + e * 0.74], [0.014, 2.12, 0.07]);
        b.cyl("stainless", [s * 1.9, 2.3, z + e * 0.86], 0.016, 1.1, undefined, "cylLow");
        b.box("stainless", [s * 1.88, 2.85, z + e * 0.86], [0.04, 0.03, 0.03]);
        b.box("stainless", [s * 1.88, 1.75, z + e * 0.86], [0.04, 0.03, 0.03]);
      }
      b.box("hazard", [s * 1.79, 1.205, z], [0.14, 0.02, 1.36]);
      // iconic centre pole in the doorway
      b.cyl("stainless", [s * 1.6, 2.2, z], 0.02, 2.1, undefined, "cylLow");
      // footstep under the door
      b.box("underframe", [s * 1.8, 0.95, z], [0.18, 0.05, 1.3]);
    }
    if (c.cab) {
      // driver side door + window
      b.box("black", [s * 1.84, 2.25, HL - 1.55], [0.012, 2.0, 0.72]);
      b.box("winOut", [s * 1.846, 2.75, HL - 1.55], [0.01, 0.7, 0.55]);
      b.box("winOut", [s * 1.846, 2.75, HL - 0.55], [0.01, 0.7, 0.6]);
      b.cyl("stainless", [s * 1.9, 2.1, HL - 1.98], 0.016, 1.2, undefined, "cylLow");
      for (const y of [0.55, 0.85]) b.box("stainless", [s * 1.85, y, HL - 1.55], [0.2, 0.03, 0.5]);
    }
  }
}

function buildInterior(b: PartBuilder, c: CoachSpec) {
  const inner = c.cab ? HL - CAB_DEPTH : HL;
  b.box("floor", [0, 1.15, (inner - HL) / 2], [3.5, 0.04, inner + HL - 0.05]);
  b.box("interior", [0, 3.82, (inner - HL) / 2], [2.9, 0.03, inner + HL - 0.05]);
  for (const s of SIDES) b.box("interior", [s * 1.735, 3.05, 0], [0.015, 1.4, COACH_LENGTH - 0.1]);

  const segments: [number, number][] = [
    [-HL + 0.4, DOOR_Z[0]! - 0.8],
    [DOOR_Z[0]! + 0.8, DOOR_Z[1]! - 0.8],
    [DOOR_Z[1]! + 0.8, DOOR_Z[2]! - 0.8],
    [DOOR_Z[2]! + 0.8, inner - 0.3],
  ];
  for (const [z0, z1] of segments) {
    const len = z1 - z0;
    const zc = (z0 + z1) / 2;
    for (const s of SIDES) {
      b.box("seat", [s * 1.47, 1.66, zc], [0.5, 0.08, len]);
      b.box("seat", [s * 1.68, 2.02, zc], [0.07, 0.62, len], [0, 0, s * 0.08]);
      b.box("seatFrame", [s * 1.48, 1.4, zc], [0.42, 0.44, len - 0.05]);
      b.cyl("stainless", [s * 1.66, 2.36, zc], 0.025, len, [Math.PI / 2, 0, 0], "cylLow");
      // luggage rack
      b.box("seatFrame", [s * 1.5, 3.3, zc], [0.4, 0.025, len]);
    }
  }
  for (let z = -HL + 1.2; z < inner - 0.6; z += 2.2) {
    for (const s of SIDES) b.box("tube", [s * 0.95, 3.79, z], [0.09, 0.04, 1.25]);
  }
  if (!c.detailedInterior) return;

  // detailed fittings for the inspectable coaches
  for (const s of SIDES) {
    b.cyl("stainless", [s * 0.72, 3.45, (inner - HL) / 2], 0.018, inner + HL - 0.4, [Math.PI / 2, 0, 0], "cylLow");
    for (const [z0, z1] of segments) {
      for (let z = z0 + 0.3; z < z1; z += 0.45) {
        b.cyl("strap", [s * 0.72, 3.3, z], 0.012, 0.3, undefined, "cylLow");
        b.add("ring", "strap", [s * 0.72, 3.08, z], [0.075, 0.075, 0.075], [0, Math.PI / 2, 0]);
      }
      for (const z of [z0, z1]) {
        b.cyl("stainless", [s * 1.2, 2.45, z], 0.02, 2.7, undefined, "cylLow");
        b.box("partition", [s * 1.45, 2.25, z], [0.55, 1.1, 0.02]);
      }
    }
    for (const z of DOOR_Z) {
      b.box("pis", [s * 1.71, 3.5, z], [0.02, 0.16, 0.85]);
    }
  }
  for (const z of [-8.2, -3.2, 3.2, c.cab ? -100 : 8.2]) {
    if (z < -50) continue;
    for (const x of [-0.6, 0.6]) {
      b.cyl("fan", [x, 3.74, z], 0.07, 0.1);
      b.add("ring", "stainless", [x, 3.68, z], [0.3, 0.3, 0.3], [Math.PI / 2, 0, 0]);
      b.add("ring", "stainless", [x, 3.64, z], [0.2, 0.2, 0.2], [Math.PI / 2, 0, 0]);
      for (let k = 0; k < 3; k++) {
        const a = (k / 3) * Math.PI * 2 + 0.4;
        b.box("fan", [x + Math.cos(a) * 0.22, 3.69, z + Math.sin(a) * 0.22], [0.38, 0.008, 0.09], [0.1, -a, 0]);
      }
    }
  }
}

function buildRoof(b: PartBuilder, c: CoachSpec) {
  const vents = c.motor ? [-1.5, 3.5, 7.5] : [-7.5, -2.5, 2.5, 7.5];
  for (const z of vents) {
    b.box("roof", [0, 4.13, z], [0.75, 0.13, 1.0]);
    b.box("black", [0, 4.13, z], [0.6, 0.135, 0.85]);
    b.box("roof", [0, 4.21, z], [0.85, 0.04, 1.1]);
  }
  if (c.cab) {
    for (const x of [-0.25, 0.25]) b.cyl("steel", [x, 4.12, HL - 0.6], 0.05, 0.3, [Math.PI / 2, 0, 0]);
  }
  if (c.motor) buildPantograph(b, PANTOGRAPH_Z);
}

export function buildPantograph(b: PartBuilder, pz: number) {
  // insulators with ceramic sheds
  for (const x of [-0.6, 0.6])
    for (const dz of [-0.65, 0.65]) {
      b.cyl("insulator", [x, 4.2, pz + dz], 0.05, 0.22);
      for (const y of [4.14, 4.2, 4.26]) b.cyl("insulator", [x, y, pz + dz], 0.09, 0.025);
    }
  b.box("bogie", [0, 4.34, pz], [1.4, 0.06, 1.45]);
  b.box("bogie", [0, 4.4, pz - 0.5], [0.9, 0.1, 0.18]);
  // single-arm pantograph, raised
  const hinge: V3 = [0, 4.42, pz - 0.5];
  const knee: V3 = [0, 5.05, pz + 0.75];
  const head: V3 = [0, 5.72, pz - 0.15];
  for (const x of [-0.18, 0.18]) b.rod("steel", [x, hinge[1], hinge[2]], [x * 0.4, knee[1], knee[2]], 0.035);
  b.rod("steel", knee, head, 0.03);
  b.rod("steel", [0, 4.42, pz - 0.2], [0, 5.05, pz + 0.7], 0.015);
  b.rod("spring", [0.25, 4.4, pz - 0.6], [0.1, 4.7, pz + 0.1], 0.04);
  b.box("carbon", [0, head[1] + 0.03, head[2]], [1.6, 0.05, 0.08]);
  b.box("copper", [0, head[1] + 0.06, head[2]], [1.5, 0.015, 0.06]);
  for (const s of SIDES) b.rod("steel", [s * 0.8, head[1] + 0.03, head[2]], [s * 1.0, head[1] - 0.12, head[2]], 0.012);
  b.rod("steel", [-0.6, head[1] - 0.02, head[2]], [0.6, head[1] - 0.02, head[2]], 0.012);
  // roof busbar and arrester
  b.cyl("copper", [0.3, 4.2, pz + 4], 0.03, 7, [Math.PI / 2, 0, 0], "cylLow");
  b.cyl("insulator", [-0.6, 4.25, pz + 1.6], 0.07, 0.3);
}

function buildUnderframe(b: PartBuilder, c: CoachSpec) {
  for (const s of SIDES) b.box("underframe", [s * 1.55, 0.98, 0], [0.12, 0.16, COACH_LENGTH - 0.2]);
  b.box("underframe", [0, 1.0, 0], [3.0, 0.08, COACH_LENGTH - 0.4]);
  if (c.motor) {
    b.box("underframe", [0.2, 0.68, -1.2], [2.5, 0.55, 4.6]);
    for (let z = -3.2; z <= 0.8; z += 0.5) b.box("black", [1.46, 0.68, z], [0.02, 0.45, 0.3]);
    b.box("bogie", [-0.6, 0.72, 2.8], [1.6, 0.45, 1.8]);
  } else {
    b.box("underframe", [0.4, 0.74, 0], [1.8, 0.42, 2.4]);
    b.box("bogie", [-0.8, 0.76, -2.6], [1.2, 0.36, 1.4]);
  }
  for (const x of [0.95, -0.95]) b.cyl("steel", [x, 0.72, 4.0], 0.2, 2.2, [Math.PI / 2, 0, 0]);
  b.rod("black", [-1.2, 0.86, -BOGIE_OFFSET], [-1.2, 0.86, BOGIE_OFFSET], 0.03);
  b.rod("copper", [1.2, 0.86, -BOGIE_OFFSET], [1.2, 0.86, BOGIE_OFFSET], 0.025);
}

export function buildBogie(b: PartBuilder, motor: boolean) {
  for (const s of SIDES) {
    const x = s * 1.02;
    b.box("bogie", [x, 0.62, 0], [0.16, 0.3, 3.3]);
    b.box("bogie", [x, 0.5, 0], [0.16, 0.18, 1.4]);
    for (const az of [1.3, -1.3]) {
      b.box("bogie", [x, WHEEL_RADIUS, az], [0.26, 0.24, 0.32]);
      b.cyl("spring", [x, 0.68, az], 0.11, 0.2);
      b.box("brake", [s * 0.86, 0.5, az - Math.sign(az) * 0.52], [0.09, 0.26, 0.14]);
      b.cyl("bogie", [s * 0.72, 0.62, az - Math.sign(az) * 0.7], 0.07, 0.22, [0, 0, Math.PI / 2]);
    }
    b.cyl("rubber", [x, 0.87, 0], 0.22, 0.18);
    b.rod("black", [s * 1.15, 0.6, 0.35], [s * 1.15, 0.95, 0.65], 0.04);
    b.box("yellow", [s * 1.1, 0.62, 1.66], [0.02, 0.1, 0.04]);
  }
  b.box("bogie", [0, 0.62, 0], [2.0, 0.22, 0.42]);
  for (const az of [0.55, -0.55]) b.box("bogie", [0, 0.6, az], [1.8, 0.1, 0.12]);
  if (motor)
    for (const az of [0.72, -0.72]) {
      b.box("underframe", [0, 0.5, az], [0.9, 0.42, 0.5]);
      b.cyl("bogie", [0.48, 0.5, az], 0.18, 0.12, [0, 0, Math.PI / 2]);
    }
}

function buildCab(b: PartBuilder, leading: boolean) {
  const f = HL;
  const w = WINDSHIELD;
  // windscreen glass + frames
  for (const s of SIDES) {
    const cx = (s * (w.x0 + w.x1)) / 2;
    b.box("glass", [cx, (w.y0 + w.y1) / 2, f + 0.01], [w.x1 - w.x0, w.y1 - w.y0, 0.015]);
    b.box("black", [cx, w.y1 + 0.03, f + 0.02], [w.x1 - w.x0 + 0.1, 0.06, 0.03]);
    b.box("black", [cx, w.y0 - 0.03, f + 0.02], [w.x1 - w.x0 + 0.1, 0.06, 0.03]);
    b.box("black", [s * (w.x1 + 0.03), (w.y0 + w.y1) / 2, f + 0.02], [0.06, w.y1 - w.y0 + 0.1, 0.03]);
    // wipers
    b.box("black", [cx + s * 0.1, w.y0 + 0.35, f + 0.04], [0.85, 0.022, 0.02], [0, 0, s * 0.75]);
    b.cyl("black", [cx + s * 0.4, w.y0 + 0.05, f + 0.04], 0.03, 0.04, [Math.PI / 2, 0, 0]);
    // small upper windows (ICF front)
    b.box("black", [s * 0.62, 3.62, f + 0.02], [0.95, 0.32, 0.03]);
    b.box("winOut", [s * 0.62, 3.62, f + 0.03], [0.85, 0.24, 0.01]);
    // rectangular headlamps in the black lamp band
    b.box("headOff", [s * 0.95, 1.82, f + 0.06], [0.42, 0.26, 0.04]);
    b.box(leading ? "headLead" : "headOff", [s * 0.95, 1.82, f + 0.085], [0.34, 0.18, 0.01]);
    for (const dx of [0.35, 0.5]) b.cyl(leading ? "tailOff" : "tailOn", [s * dx, dx === 0.35 ? 1.92 : 1.72, f + 0.065], 0.04, 0.02, [Math.PI / 2, 0, 0], "cylLow");
    // roof horns
    b.cyl("band", [s * 0.4, 4.15, f - 0.3], 0.04, 0.25, [Math.PI / 2, 0, 0], "cylLow");
    b.cyl("band", [s * 0.4, 4.15, f - 0.16], 0.09, 0.06, [Math.PI / 2, 0, 0]);
    // white lower surround
    b.box("body", [s * 1.4, 1.35, f + 0.015], [0.86, 0.5, 0.02]);
  }
  b.box("black", [0, 1.82, f + 0.04], [2.9, 0.42, 0.04]);
  b.box("body", [0, 1.18, f + 0.015], [3.4, 0.25, 0.02]);
  b.box("band", [0, 1.42, f + 0.017], [3.5, 0.12, 0.02]);
  b.box("front", [0, (w.y0 + w.y1) / 2, f + 0.02], [0.2, w.y1 - w.y0 + 0.1, 0.04]);
  // destination board between the upper windows
  b.box("dest", [0, 3.88, f + 0.03], [0.9, 0.16, 0.01]);
  // lower front: hazard stripe, buffer beam, coupler, pilot
  b.box("underframe", [0, 1.05, f + 0.12], [3.3, 0.3, 0.26]);
  b.cyl("bogie", [0, 0.95, f + 0.42], 0.1, 0.5, [Math.PI / 2, 0, 0]);
  b.box("black", [0, 0.95, f + 0.7], [0.32, 0.26, 0.12]);
  b.box("underframe", [0, 0.42, f + 0.3], [2.6, 0.5, 0.06], [-0.35, 0, 0]);
  for (const s of SIDES) {
    b.rod("black", [s * 0.5, 0.75, f + 0.15], [s * 0.9, 0.3, f + 0.36], 0.03);
    b.cyl("rubber", [s * 0.7, 0.85, f + 0.28], 0.05, 0.25, [Math.PI / 2, 0, 0]);
    b.cyl("stainless", [s * 0.4, 1.95, f + 0.07], 0.015, 0.4, [0, 0, Math.PI / 2], "cylLow");
  }

  // ---- driver cabin interior ----
  const pz = f - CAB_DEPTH;
  b.box("interior", [0, 2.45, pz], [3.48, 2.6, 0.05]);
  b.box("black", [-0.9, 2.15, pz + 0.03], [0.7, 1.95, 0.02]);
  b.box("floor", [0, 1.15, f - CAB_DEPTH / 2], [3.5, 0.04, CAB_DEPTH]);
  b.box("interior", [0, 3.82, f - CAB_DEPTH / 2], [3.4, 0.03, CAB_DEPTH]);
  // desk
  b.box("desk", [0, 1.65, f - 0.45], [3.4, 1.0, 0.7]);
  b.box("panel", [0, 2.22, f - 0.6], [3.2, 0.06, 0.62], [-0.32, 0, 0]);
  // instruments in front of the motorman (left side, +x)
  b.box("speedo", [0.75, 2.27, f - 0.5], [0.26, 0.26, 0.01], [-1.25, 0, 0]);
  for (const x of [1.08, 0.42]) b.box("gauge", [x, 2.25, f - 0.47], [0.18, 0.18, 0.01], [-1.25, 0, 0]);
  b.box("panel", [-0.6, 2.26, f - 0.5], [0.8, 0.3, 0.02], [-1.25, 0, 0]);
  for (let i = 0; i < 6; i++)
    b.cyl(i % 3 === 0 ? "green" : i % 3 === 1 ? "amber" : "red", [-0.9 + i * 0.12, 2.3, f - 0.47], 0.025, 0.02, [0.3, 0, 0], "cylLow");
  // master controller (traction) - left hand
  b.box("black", [0.25, 2.3, f - 0.75], [0.16, 0.1, 0.25]);
  b.rod("steel", [0.25, 2.33, f - 0.72], [0.25, 2.52, f - 0.8], 0.018);
  b.add("sphere", "black", [0.25, 2.54, f - 0.81], [0.04, 0.04, 0.04]);
  // reverser key
  b.box("panel", [0.45, 2.3, f - 0.85], [0.12, 0.06, 0.12]);
  b.box("yellow", [0.45, 2.36, f - 0.85], [0.03, 0.08, 0.06]);
  // brake handle - right hand
  b.box("black", [1.2, 2.32, f - 0.78], [0.18, 0.1, 0.18]);
  b.rod("steel", [1.2, 2.36, f - 0.78], [1.32, 2.46, f - 0.9], 0.02);
  b.add("sphere", "red", [1.33, 2.47, f - 0.91], [0.045, 0.045, 0.045]);
  // horn push buttons
  for (const x of [1.42, -1.3]) b.cyl("yellow", [x, 2.3, f - 0.82], 0.035, 0.03, [0.3, 0, 0], "cylLow");
  // driver seat
  b.cyl("steel", [0.75, 1.4, f - 1.45], 0.05, 0.5);
  b.box("cabSeat", [0.75, 1.72, f - 1.45], [0.52, 0.1, 0.5]);
  b.box("cabSeat", [0.75, 2.1, f - 1.72], [0.5, 0.7, 0.08], [-0.12, 0, 0]);
  b.box("cabSeat", [-0.75, 1.72, f - 1.45], [0.45, 0.1, 0.45]);
  b.box("tube", [0, 3.79, f - 1.2], [0.6, 0.04, 0.1]);
}

function buildEnd(b: PartBuilder, end: number) {
  const z = end * HL;
  b.box("rubber", [0, 2.2, z + end * 0.18], [1.2, 2.25, 0.36]);
  for (const dy of [-0.9, -0.45, 0, 0.45, 0.9]) b.box("black", [0, 2.2 + dy, z + end * 0.18], [1.24, 0.04, 0.37]);
  b.box("doorway", [0, 2.2, z], [0.9, 2.05, 0.02]);
  b.cyl("bogie", [0, 0.95, z + end * 0.18], 0.09, 0.36, [Math.PI / 2, 0, 0]);
  b.box("black", [0, 0.95, z + end * 0.35], [0.24, 0.2, 0.04]);
  for (const s of SIDES) b.rod("rubber", [s * 0.8, 1.0, z], [s * 0.6, 0.9, z + end * 0.35], 0.03);
}

export { RAIL_HALF_GAUGE };
