import { useFrame } from "@react-three/fiber";
import { useEffect, useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { geometryByKey, getGeometries } from "./geometries";
import { applyLights, applyLivery, createMaterials, disposeMaterials, materialByKey, type MaterialSet } from "./materials";
import { coachLabelTexture, routeLettersTexture } from "./textures";
import { buildTrain, type TrainParts } from "./TrainBuilder";
import {
  buildTrainLayout,
  coachZ,
  COACH_LENGTH,
  FRONT_FACE_Z,
  LIVERIES,
  RAIL_HALF_GAUGE,
  REAR_FACE_Z,
  type CoachSpec,
} from "./TrainConfig";
import { trainRuntime, useTrainStore } from "./store";

const NO_SHADOW = new Set(["glass", "winIn", "tube", "dest", "pis", "partition"]);

function InstancedBatch({
  geometry,
  material,
  matrices,
  shadow,
}: {
  geometry: THREE.BufferGeometry;
  material: THREE.Material;
  matrices: THREE.Matrix4[];
  shadow: boolean;
}) {
  const ref = useRef<THREE.InstancedMesh>(null);
  useLayoutEffect(() => {
    const mesh = ref.current!;
    matrices.forEach((m, i) => mesh.setMatrixAt(i, m));
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
  }, [matrices]);
  return (
    <instancedMesh
      ref={ref}
      args={[geometry, material, matrices.length]}
      castShadow={shadow}
      receiveShadow
      frustumCulled={false}
    />
  );
}

/** Sliding door leaves: instanced, matrices rewritten while doors move. */
function DoorLeaves({ parts, mats }: { parts: TrainParts; mats: MaterialSet }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const geos = getGeometries();
  const tmp = useMemo(() => ({ m: new THREE.Matrix4(), q: new THREE.Quaternion(), p: new THREE.Vector3(), s: new THREE.Vector3(0.03, 2.05, 0.68) }), []);
  const write = (p: number) => {
    const mesh = ref.current;
    if (!mesh) return;
    parts.leaves.forEach((l, i) => {
      tmp.p.set(l.side * 1.874, 2.225, l.z + l.dir * (0.34 + p * 0.66));
      tmp.m.compose(tmp.p, tmp.q, tmp.s).premultiply(l.coach);
      mesh.setMatrixAt(i, tmp.m);
    });
    mesh.instanceMatrix.needsUpdate = true;
  };
  useLayoutEffect(() => write(trainRuntime.doorProgress));
  useFrame((_, delta) => {
    const target = useTrainStore.getState().doorsOpen ? 1 : 0;
    const cur = trainRuntime.doorProgress;
    if (Math.abs(target - cur) < 0.0005) return;
    const dt = Math.min(delta, 0.05);
    trainRuntime.doorProgress = cur + Math.sign(target - cur) * Math.min(Math.abs(target - cur), dt / 1.6);
    write(trainRuntime.doorProgress);
  });
  return (
    <instancedMesh ref={ref} args={[geos.box, mats.leaf, parts.leaves.length]} castShadow receiveShadow frustumCulled={false} />
  );
}

/** Wheelsets: every wheel is its own instance so it can rotate independently. */
function Wheelsets({ parts, mats }: { parts: TrainParts; mats: MaterialSet }) {
  const wheels = useRef<THREE.InstancedMesh>(null);
  const axles = useRef<THREE.InstancedMesh>(null);
  const geos = getGeometries();
  const local = useMemo(() => {
    const mk = (x: number, rz: number) =>
      new THREE.Matrix4().compose(
        new THREE.Vector3(x, 0, 0),
        new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0, rz)),
        new THREE.Vector3(1, 1, 1),
      );
    return {
      wheels: [mk(RAIL_HALF_GAUGE, Math.PI / 2), mk(-RAIL_HALF_GAUGE, -Math.PI / 2)],
      axle: new THREE.Matrix4().compose(
        new THREE.Vector3(),
        new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0, Math.PI / 2)),
        new THREE.Vector3(0.075, 2.05, 0.075),
      ),
    };
  }, []);
  const tmp = useMemo(() => ({ rot: new THREE.Matrix4(), m: new THREE.Matrix4() }), []);
  const write = (angle: number) => {
    if (!wheels.current || !axles.current) return;
    tmp.rot.makeRotationX(angle);
    parts.axles.forEach((a, i) => {
      local.wheels.forEach((w, k) => {
        tmp.m.copy(a.matrix).multiply(tmp.rot).multiply(w);
        wheels.current!.setMatrixAt(i * 2 + k, tmp.m);
      });
      tmp.m.copy(a.matrix).multiply(tmp.rot).multiply(local.axle);
      axles.current!.setMatrixAt(i, tmp.m);
    });
    wheels.current.instanceMatrix.needsUpdate = true;
    axles.current.instanceMatrix.needsUpdate = true;
  };
  useLayoutEffect(() => write(trainRuntime.wheelAngle));
  useFrame((_, delta) => {
    const demo = useTrainStore.getState().wheelDemo;
    const speed = demo ? 4 : trainRuntime.speed;
    if (!speed) return;
    trainRuntime.wheelAngle += Math.min(delta, 0.05) * speed;
    write(trainRuntime.wheelAngle);
  });
  return (
    <>
      <instancedMesh ref={wheels} args={[geos.wheel, mats.steel, parts.axles.length * 2]} castShadow frustumCulled={false} />
      <instancedMesh ref={axles} args={[geos.cyl, mats.bogie, parts.axles.length]} castShadow frustumCulled={false} />
    </>
  );
}

function CoachLabels({ layout, short }: { layout: CoachSpec[]; short: string }) {
  const letters = useMemo(
    () => new THREE.MeshStandardMaterial({ map: routeLettersTexture(short), transparent: true, roughness: 0.4 }),
    [short],
  );
  useEffect(() => () => (letters.map?.dispose(), letters.dispose()), [letters]);
  const labels = useMemo(
    () =>
      layout.map((c) => {
        const map = coachLabelTexture(c);
        return { c, mat: new THREE.MeshStandardMaterial({ map, transparent: true, roughness: 0.5 }) };
      }),
    [layout],
  );
  useEffect(
    () => () =>
      labels.forEach((l) => {
        l.mat.map?.dispose();
        l.mat.dispose();
      }),
    [labels],
  );
  const geo = getGeometries().box;
  return (
    <>
      {labels.map(({ c, mat }) => (
        <group key={c.index} position={[0, 0, c.z]} rotation={[0, c.flipped ? Math.PI : 0, 0]}>
          {[1, -1].map((s) => (
            <mesh
              key={s}
              geometry={geo}
              material={mat}
              position={[s * 1.79, 1.27, -COACH_LENGTH / 2 + 1.7]}
              rotation={[0, 0, -s * 0.31]}
              scale={[0.004, 0.22, 0.88]}
            />
          ))}
          {[1, -1].map((s) => (
            <mesh key={`r${s}`} geometry={geo} material={letters} position={[s * 1.843, 1.74, 2.6]} scale={[0.004, 0.46, 0.95]} />
          ))}
        </group>
      ))}
    </>
  );
}

function TrainLights() {
  const lights = useTrainStore((s) => s.lights);
  const spot = useRef<THREE.SpotLight>(null);
  const target = useMemo(() => {
    const o = new THREE.Object3D();
    o.position.set(0, 0, FRONT_FACE_Z + 40);
    return o;
  }, []);
  useEffect(() => {
    if (spot.current) spot.current.target = target;
  }, [target]);
  const interiorZ = [coachZ(0) - 6, coachZ(0) + 1, coachZ(1) - 5, coachZ(1) + 4];
  return (
    <>
      <primitive object={target} />
      <spotLight
        ref={spot}
        position={[0, 2.9, FRONT_FACE_Z + 0.4]}
        angle={0.42}
        penumbra={0.6}
        distance={70}
        intensity={lights.headlights ? 250 : 0}
        color="#fff4d6"
      />
      <pointLight position={[0, 1.8, REAR_FACE_Z - 0.6]} intensity={lights.tail ? 6 : 0} distance={8} color="#ff2a1a" />
      {interiorZ.map((z) => (
        <pointLight key={z} position={[0, 3.5, z]} intensity={lights.interior ? 9 : 0} distance={9} decay={1.6} color="#f2f5ff" />
      ))}
      <pointLight position={[0.3, 3.6, FRONT_FACE_Z - 1.2]} intensity={lights.interior ? 2.5 : 0} distance={4} color="#f2f5ff" />
    </>
  );
}

export function Train() {
  const liveryId = useTrainStore((s) => s.livery);
  const lights = useTrainStore((s) => s.lights);
  const livery = LIVERIES[liveryId];
  const layout = useMemo(() => buildTrainLayout(livery), [livery]);
  const parts = useMemo(() => buildTrain(buildTrainLayout(LIVERIES.western)), []);
  const mats = useMemo(() => createMaterials(LIVERIES.western), []);

  useEffect(() => () => disposeMaterials(mats), [mats]);
  useEffect(() => applyLivery(mats, livery), [mats, livery]);
  useEffect(() => applyLights(mats, lights), [mats, lights]);

  const batches = useMemo(() => [...parts.builder.batches.entries()], [parts]);

  return (
    <group name="mumbai-emu-12car">
      {batches.map(([key, b]) => (
        <InstancedBatch
          key={key}
          geometry={geometryByKey(b.geo)}
          material={materialByKey(mats, b.mat)}
          matrices={b.matrices}
          shadow={!NO_SHADOW.has(b.mat)}
        />
      ))}
      <DoorLeaves parts={parts} mats={mats} />
      <Wheelsets parts={parts} mats={mats} />
      <CoachLabels layout={layout} short={livery.short} />
      <TrainLights />
    </group>
  );
}
