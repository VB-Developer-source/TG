# Roadmap
- [x] Section 02: 12-coach EMU, liveries, interior, cab, lights, preview camera, audio
- [x] Match user's real photos: WR white/magenta livery, ICF yellow front w/ black lamp band, pink cab desk, stainless interior with navy seats
