import * as THREE from "three";
import { mulberry32, range } from "../core/random";
import { COACH, type CoachSpec, type Livery } from "./TrainConfig";

/**
 * Procedural canvas textures for the train. Nothing is downloaded.
 */

type Ctx = CanvasRenderingContext2D;

function makeCanvas(width: number, height = width): [HTMLCanvasElement, Ctx] {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("2D canvas is not available");
  return [canvas, ctx];
}

function toTexture(canvas: HTMLCanvasElement, repeatS = false): THREE.CanvasTexture {
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = repeatS ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.anisotropy = 4;
  return texture;
}

/* ------------------------------------------------------------------ */
/* Livery: varies with height, tiles every 4 m along the coach.        */
/* ------------------------------------------------------------------ */

export const LIVERY_SPAN = { y0: COACH.solebarY, y1: COACH.eaveY, tile: 4 } as const;
const LIVERY_H = 512;
const LIVERY_W = 256;

const rowAt = (y: number) => (1 - (y - LIVERY_SPAN.y0) / (LIVERY_SPAN.y1 - LIVERY_SPAN.y0)) * LIVERY_H;

export function liveryTexture(livery: Livery): THREE.CanvasTexture {
  const rng = mulberry32(livery.id.length * 977);
  const [c, ctx] = makeCanvas(LIVERY_W, LIVERY_H);
  const band = (y0: number, y1: number, color: string) => {
    ctx.fillStyle = color;
    ctx.fillRect(0, rowAt(y1), LIVERY_W, rowAt(y0) - rowAt(y1));
  };
  band(LIVERY_SPAN.y0, LIVERY_SPAN.y1, livery.body);
  band(1.02, 1.22, livery.skirt);
  band(1.6, 1.98, livery.band);
  band(2.02, 2.06, livery.accent);
  band(3.12, 3.32, livery.band);
  band(3.33, 3.35, livery.accent);

  // Panel seams every metre.
  ctx.fillStyle = "rgba(20,20,24,0.16)";
  for (let x = 0; x < LIVERY_W; x += LIVERY_W / 4) ctx.fillRect(x, 0, 1.5, LIVERY_H);
  ctx.fillStyle = "rgba(255,255,255,0.08)";
  for (let x = 2; x < LIVERY_W; x += LIVERY_W / 4) ctx.fillRect(x, 0, 1, LIVERY_H);

  // Road grime rising from the solebar and streaks under the windows.
  const grime = ctx.createLinearGradient(0, LIVERY_H, 0, rowAt(1.9));
  grime.addColorStop(0, "rgba(46,36,28,0.45)");
  grime.addColorStop(1, "rgba(46,36,28,0)");
  ctx.fillStyle = grime;
  ctx.fillRect(0, rowAt(1.9), LIVERY_W, LIVERY_H - rowAt(1.9));
  for (let i = 0; i < 26; i++) {
    const x = rng() * LIVERY_W;
    const top = rowAt(COACH.window.sill - 0.02);
    const h = range(rng, 20, 90);
    const g = ctx.createLinearGradient(0, top, 0, top + h);
    g.addColorStop(0, "rgba(40,34,28,0.22)");
    g.addColorStop(1, "rgba(40,34,28,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x, top, range(rng, 2, 7), h);
  }
  return toTexture(c, true);
}

/** Writes livery UVs: u along `axis` in 4 m tiles, v by height. */
export function liveryUV(geo: THREE.BufferGeometry, axis: "x" | "z"): THREE.BufferGeometry {
  const pos = geo.getAttribute("position");
  const uv = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    const along = axis === "z" ? pos.getZ(i) : pos.getX(i);
    uv[i * 2] = along / LIVERY_SPAN.tile;
    uv[i * 2 + 1] = (pos.getY(i) - LIVERY_SPAN.y0) / (LIVERY_SPAN.y1 - LIVERY_SPAN.y0);
  }
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  return geo;
}

/* ------------------------------------------------------------------ */
/* Display atlas: destination LED, route board, coach number plates.   */
/* ------------------------------------------------------------------ */

const ATLAS = 1024;
const PLATE = { w: 256, h: 80, top: 384, cols: 4 } as const;

export interface UVRect {
  u0: number;
  v0: number;
  u1: number;
  v1: number;
}

const rect = (x: number, y: number, w: number, h: number): UVRect => ({
  u0: x / ATLAS,
  u1: (x + w) / ATLAS,
  v1: 1 - y / ATLAS,
  v0: 1 - (y + h) / ATLAS,
});

export const ATLAS_DESTINATION = rect(0, 0, ATLAS, 128);
export const ATLAS_ROUTE = rect(0, 128, ATLAS, 256);
export const MAX_PLATES = PLATE.cols * Math.floor((ATLAS - PLATE.top) / PLATE.h);

export function plateRect(index: number): UVRect {
  const col = index % PLATE.cols;
  const row = Math.floor(index / PLATE.cols);
  return rect(col * PLATE.w, PLATE.top + row * PLATE.h, PLATE.w, PLATE.h);
}

/** Remaps a 0..1 UV attribute into an atlas rectangle. */
export function remapUV(geo: THREE.BufferGeometry, r: UVRect): THREE.BufferGeometry {
  const uv = geo.getAttribute("uv");
  for (let i = 0; i < uv.count; i++) {
    uv.setXY(i, r.u0 + uv.getX(i) * (r.u1 - r.u0), r.v0 + uv.getY(i) * (r.v1 - r.v0));
  }
  uv.needsUpdate = true;
  return geo;
}

/** Renders text as an amber LED dot matrix. */
function drawLedText(
  ctx: Ctx,
  x: number,
  y: number,
  w: number,
  h: number,
  cols: number,
  draw: (low: Ctx, cw: number, ch: number) => void,
) {
  const rows = Math.round((cols * h) / w);
  const [, low] = makeCanvas(cols, rows);
  low.fillStyle = "#000";
  low.fillRect(0, 0, cols, rows);
  low.fillStyle = "#fff";
  low.textBaseline = "middle";
  draw(low, cols, rows);
  const data = low.getImageData(0, 0, cols, rows).data;
  const pitch = w / cols;
  ctx.fillStyle = "#050302";
  ctx.fillRect(x, y, w, h);
  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < cols; i++) {
      const lit = (data[(j * cols + i) * 4] ?? 0) > 110;
      ctx.fillStyle = lit ? "#ffb02e" : "#2a1606";
      ctx.beginPath();
      ctx.arc(x + (i + 0.5) * pitch, y + (j + 0.5) * pitch, pitch * (lit ? 0.42 : 0.3), 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

function drawRouteBoard(ctx: Ctx, livery: Livery, y0: number) {
  const w = ATLAS;
  const h = 256;
  ctx.fillStyle = "#0a1018";
  ctx.fillRect(0, y0, w, h);
  ctx.strokeStyle = "#2b3746";
  ctx.lineWidth = 6;
  ctx.strokeRect(3, y0 + 3, w - 6, h - 6);
  ctx.fillStyle = "#ffb02e";
  ctx.font = `700 26px "IBM Plex Mono", monospace`;
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  ctx.fillText(`${livery.name.toUpperCase()}  ·  TOWARDS ${livery.destination}`, 28, y0 + 34);
  const stations = livery.stations;
  const lineY = y0 + 150;
  const x0 = 60;
  const x1 = w - 60;
  ctx.fillStyle = livery.band;
  ctx.fillRect(x0, lineY - 6, x1 - x0, 12);
  ctx.fillStyle = "rgba(255,255,255,0.35)";
  ctx.fillRect(x0, lineY - 6, x1 - x0, 3);
  stations.forEach((name, i) => {
    const x = x0 + ((x1 - x0) * i) / Math.max(1, stations.length - 1);
    const current = name === "Dadar" || (i === 3 && !stations.includes("Dadar"));
    ctx.beginPath();
    ctx.arc(x, lineY, current ? 14 : 10, 0, Math.PI * 2);
    ctx.fillStyle = current ? "#ffb02e" : "#f4f1ea";
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = livery.band;
    ctx.stroke();
    ctx.save();
    ctx.translate(x, i % 2 === 0 ? lineY - 26 : lineY + 26);
    ctx.fillStyle = current ? "#ffb02e" : "#d9dee6";
    ctx.font = `600 ${current ? 22 : 19}px "IBM Plex Sans", Arial, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = i % 2 === 0 ? "bottom" : "top";
    ctx.fillText(name.toUpperCase(), 0, 0);
    ctx.restore();
  });
  ctx.fillStyle = "#7f8b99";
  ctx.font = `500 18px "IBM Plex Mono", monospace`;
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";
  ctx.fillText("NEXT STATION  DADAR", w - 28, y0 + 34);
}

function drawPlate(ctx: Ctx, coach: CoachSpec, livery: Livery, index: number) {
  const col = index % PLATE.cols;
  const row = Math.floor(index / PLATE.cols);
  const x = col * PLATE.w;
  const y = PLATE.top + row * PLATE.h;
  ctx.fillStyle = livery.band;
  ctx.fillRect(x, y, PLATE.w, PLATE.h);
  ctx.fillStyle = livery.body;
  ctx.font = `700 46px "IBM Plex Mono", monospace`;
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  ctx.fillText(coach.number, x + 16, y + PLATE.h / 2 + 2);
  if (coach.marking) {
    const label = coach.marking === "first" ? "1ST" : "LADIES";
    const tagW = coach.marking === "first" ? 60 : 92;
    ctx.fillStyle = coach.marking === "first" ? livery.accent : "#e2e2e2";
    ctx.fillRect(x + PLATE.w - tagW - 10, y + 18, tagW, PLATE.h - 36);
    ctx.fillStyle = "#151515";
    ctx.font = `700 20px "IBM Plex Sans", Arial, sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText(label, x + PLATE.w - 10 - tagW / 2, y + PLATE.h / 2 + 1);
  }
}

export function displayAtlas(livery: Livery, coaches: CoachSpec[], destination: { name: string; code: string }) {
  if (coaches.length > MAX_PLATES) throw new Error(`At most ${MAX_PLATES} coaches fit the plate atlas`);
  const [c, ctx] = makeCanvas(ATLAS);
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, ATLAS, ATLAS);
  drawLedText(ctx, 0, 0, ATLAS, 128, 160, (low, cw, ch) => {
    low.font = `700 ${Math.round(ch * 0.82)}px "IBM Plex Sans", Arial, sans-serif`;
    low.textAlign = "left";
    low.fillText(destination.name, 3, ch / 2 + 1);
    low.textAlign = "right";
    low.fillText(destination.code, cw - 3, ch / 2 + 1);
  });
  drawRouteBoard(ctx, livery, 128);
  coaches.forEach((coach, i) => drawPlate(ctx, coach, livery, i));
  return toTexture(c);
}

/* ------------------------------------------------------------------ */
/* Driver's instrument panel.                                          */
/* ------------------------------------------------------------------ */

const PANEL_W = 1024;
const PANEL_H = 512;
/** Speedometer dial in panel UV space (u, v and radius as a fraction of width). */
export const SPEEDO = { u: 300 / PANEL_W, v: 1 - 262 / PANEL_H, r: 170 / PANEL_W, maxKmh: 120 } as const;
/** Needle angle in radians (0 = pointing up) for a speed. Sweeps 270°. */
export function speedoAngle(kmh: number): number {
  const t = Math.min(1, Math.max(0, kmh / SPEEDO.maxKmh));
  return -((-135 + 270 * t) * Math.PI) / 180;
}

function dial(ctx: Ctx, cx: number, cy: number, r: number, max: number, major: number, label: string, needle?: number) {
  ctx.fillStyle = "#0b0c0e";
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = Math.max(3, r * 0.05);
  ctx.strokeStyle = "#8b9097";
  ctx.stroke();
  const a0 = (-225 * Math.PI) / 180;
  const sweep = (270 * Math.PI) / 180;
  const steps = max / major;
  for (let i = 0; i <= steps * 2; i++) {
    const a = a0 + (sweep * i) / (steps * 2);
    const big = i % 2 === 0;
    const r0 = r * (big ? 0.78 : 0.85);
    ctx.strokeStyle = "#e9e6dd";
    ctx.lineWidth = big ? 3 : 1.5;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
    ctx.lineTo(cx + Math.cos(a) * r * 0.92, cy + Math.sin(a) * r * 0.92);
    ctx.stroke();
    if (big) {
      ctx.fillStyle = "#e9e6dd";
      ctx.font = `600 ${Math.round(r * 0.16)}px "IBM Plex Mono", monospace`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(String((i / 2) * major), cx + Math.cos(a) * r * 0.62, cy + Math.sin(a) * r * 0.62);
    }
  }
  ctx.fillStyle = "#9aa1a9";
  ctx.font = `600 ${Math.round(r * 0.15)}px "IBM Plex Sans", Arial, sans-serif`;
  ctx.textAlign = "center";
  ctx.fillText(label, cx, cy + r * 0.48);
  if (needle !== undefined) {
    const a = a0 + sweep * needle;
    ctx.strokeStyle = "#ff6a2b";
    ctx.lineWidth = Math.max(2, r * 0.05);
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(a) * r * 0.75, cy + Math.sin(a) * r * 0.75);
    ctx.stroke();
  }
  ctx.fillStyle = "#3a3f45";
  ctx.beginPath();
  ctx.arc(cx, cy, r * 0.08, 0, Math.PI * 2);
  ctx.fill();
}

export function instrumentTexture(): THREE.CanvasTexture {
  const [c, ctx] = makeCanvas(PANEL_W, PANEL_H);
  ctx.fillStyle = "#262a2f";
  ctx.fillRect(0, 0, PANEL_W, PANEL_H);
  ctx.strokeStyle = "#1a1d21";
  ctx.lineWidth = 4;
  for (const x of [530, 1010]) {
    ctx.beginPath();
    ctx.moveTo(x, 10);
    ctx.lineTo(x, PANEL_H - 10);
    ctx.stroke();
  }
  dial(ctx, 300, 262, 170, SPEEDO.maxKmh, 20, "km/h");
  ctx.fillStyle = "#e9e6dd";
  ctx.font = `600 18px "IBM Plex Mono", monospace`;
  ctx.textAlign = "center";
  ctx.fillText("SPEED  (placeholder)", 300, 470);
  dial(ctx, 625, 150, 70, 10, 2, "MR kg/cm²", 0.82);
  dial(ctx, 775, 150, 70, 10, 2, "BP kg/cm²", 0.5);
  dial(ctx, 925, 150, 70, 10, 2, "BC kg/cm²", 0.06);
  // Digital readouts.
  const readout = (x: number, y: number, label: string, value: string) => {
    ctx.fillStyle = "#0a0d0a";
    ctx.fillRect(x, y, 170, 62);
    ctx.fillStyle = "#62f08a";
    ctx.font = `600 32px "IBM Plex Mono", monospace`;
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";
    ctx.fillText(value, x + 160, y + 33);
    ctx.fillStyle = "#9aa1a9";
    ctx.font = `600 15px "IBM Plex Sans", Arial, sans-serif`;
    ctx.textAlign = "left";
    ctx.fillText(label, x, y - 12);
  };
  readout(570, 300, "OHE VOLTAGE", "25.0 kV");
  readout(780, 300, "TRACTION CURRENT", "0 A");
  const lamps: [string, string][] = [
    ["DOORS", "#62f08a"],
    ["PANTO", "#62f08a"],
    ["VCB", "#ffb02e"],
    ["BRAKE", "#ff4b3a"],
    ["FAULT", "#3a2020"],
  ];
  lamps.forEach(([label, color], i) => {
    const x = 590 + i * 82;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, 430, 18, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#9aa1a9";
    ctx.font = `600 14px "IBM Plex Sans", Arial, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    ctx.fillText(label, x, 456);
  });
  return toTexture(c);
}

/* ------------------------------------------------------------------ */
/* Small helpers.                                                      */
/* ------------------------------------------------------------------ */

/** 2 m tile of grey anti-slip floor. */
export function floorTexture(): THREE.CanvasTexture {
  const rng = mulberry32(42);
  const size = 256;
  const [c, ctx] = makeCanvas(size);
  ctx.fillStyle = "#5c5f63";
  ctx.fillRect(0, 0, size, size);
  for (let i = 0; i < 2600; i++) {
    ctx.fillStyle = rng() < 0.5 ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.12)";
    ctx.fillRect(rng() * size, rng() * size, 2, 2);
  }
  for (let i = 0; i < 10; i++) {
    const g = ctx.createRadialGradient(rng() * size, rng() * size, 0, rng() * size, rng() * size, range(rng, 20, 60));
    g.addColorStop(0, "rgba(30,26,22,0.18)");
    g.addColorStop(1, "rgba(30,26,22,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
  }
  const t = toTexture(c, true);
  t.wrapT = THREE.RepeatWrapping;
  return t;
}

/** Soft radial glow used for lamp halos (additive sprites). */
export function glowTexture(): THREE.CanvasTexture {
  const size = 128;
  const [c, ctx] = makeCanvas(size);
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.18, "rgba(255,255,255,0.55)");
  g.addColorStop(0.5, "rgba(255,255,255,0.12)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  return toTexture(c);
}
