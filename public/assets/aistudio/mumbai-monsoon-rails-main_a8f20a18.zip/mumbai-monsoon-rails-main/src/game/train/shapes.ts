import * as THREE from "three";

/** Rounded rectangle path in a shape's 2D plane. */
export function roundedRect<T extends THREE.Path>(path: T, x0: number, y0: number, x1: number, y1: number, r: number): T {
  const rr = Math.min(r, (x1 - x0) / 2, (y1 - y0) / 2);
  path.moveTo(x0 + rr, y0);
  path.lineTo(x1 - rr, y0);
  if (rr > 0) path.quadraticCurveTo(x1, y0, x1, y0 + rr);
  path.lineTo(x1, y1 - rr);
  if (rr > 0) path.quadraticCurveTo(x1, y1, x1 - rr, y1);
  path.lineTo(x0 + rr, y1);
  if (rr > 0) path.quadraticCurveTo(x0, y1, x0, y1 - rr);
  path.lineTo(x0, y0 + rr);
  if (rr > 0) path.quadraticCurveTo(x0, y0, x0 + rr, y0);
  return path;
}

export function holeRect(x0: number, y0: number, x1: number, y1: number, r: number): THREE.Path {
  return roundedRect(new THREE.Path(), x0, y0, x1, y1, r);
}

/** Rectangle whose top follows an elliptical arch (coach end and front walls). */
export function archShape(halfW: number, y0: number, eave: number, crown: number, segments = 14): THREE.Shape {
  const s = new THREE.Shape();
  s.moveTo(-halfW, y0);
  s.lineTo(halfW, y0);
  s.lineTo(halfW, eave);
  for (let i = 1; i <= segments; i++) {
    const phi = (i / segments) * Math.PI;
    s.lineTo(halfW * Math.cos(phi), eave + (crown - eave) * Math.sin(phi));
  }
  s.closePath();
  return s;
}

/** Curved roof skin cross-section of thickness t. */
export function roofShellShape(halfW: number, eave: number, crown: number, t: number, segments = 18): THREE.Shape {
  const s = new THREE.Shape();
  s.moveTo(halfW, eave);
  for (let i = 1; i <= segments; i++) {
    const phi = (i / segments) * Math.PI;
    s.lineTo(halfW * Math.cos(phi), eave + (crown - eave) * Math.sin(phi));
  }
  const ih = halfW - t;
  const ic = crown - t;
  for (let i = segments; i >= 0; i--) {
    const phi = (i / segments) * Math.PI;
    s.lineTo(ih * Math.cos(phi), eave + (ic - eave) * Math.sin(phi));
  }
  s.closePath();
  return s;
}

/** Height of an elliptical roof at lateral offset x. */
export function archHeightAt(x: number, halfW: number, eave: number, crown: number): number {
  const t = Math.min(1, Math.abs(x) / halfW);
  return eave + (crown - eave) * Math.sqrt(1 - t * t);
}

const extrudeOpts = (depth: number): THREE.ExtrudeGeometryOptions => ({
  depth,
  bevelEnabled: false,
  steps: 1,
  curveSegments: 3,
});

/**
 * Extrudes a (z, y) side profile across x. side = +1 puts the slab at
 * [xOuter - depth, xOuter], side = -1 mirrors it to [-xOuter, -xOuter + depth]
 * (by rotation, so winding and normals stay correct).
 */
export function sideSlab(shape: THREE.Shape, depth: number, side: 1 | -1, xOuter: number): THREE.BufferGeometry {
  const g = new THREE.ExtrudeGeometry(shape, extrudeOpts(depth));
  g.rotateY(-Math.PI / 2);
  g.translate(side > 0 ? xOuter : -xOuter + depth, 0, 0);
  return g;
}

/** Extrudes an (x, y) profile along z between z0 and z1. */
export function slabZ(shape: THREE.Shape, z0: number, z1: number): THREE.BufferGeometry {
  const g = new THREE.ExtrudeGeometry(shape, extrudeOpts(z1 - z0));
  g.translate(0, 0, z0);
  return g;
}

/** Axis-aligned box from min/max corners. */
export function boxMinMax(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number): THREE.BufferGeometry {
  return new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
}

export function cylZ(r: number, z0: number, z1: number, x: number, y: number, seg = 10, rTop = r): THREE.BufferGeometry {
  const g = new THREE.CylinderGeometry(rTop, r, z1 - z0, seg);
  g.rotateX(Math.PI / 2);
  return g.translate(x, y, (z0 + z1) / 2);
}

export function cylX(r: number, x0: number, x1: number, y: number, z: number, seg = 10): THREE.BufferGeometry {
  const g = new THREE.CylinderGeometry(r, r, x1 - x0, seg);
  g.rotateZ(Math.PI / 2);
  return g.translate((x0 + x1) / 2, y, z);
}

export function cylY(r: number, y0: number, y1: number, x: number, z: number, seg = 10): THREE.BufferGeometry {
  return new THREE.CylinderGeometry(r, r, y1 - y0, seg).translate(x, (y0 + y1) / 2, z);
}

/** Flat quad facing +x / -x / +z / -z with 0..1 UVs. */
export function quad(
  w: number,
  h: number,
  facing: "+x" | "-x" | "+z" | "-z",
  x: number,
  y: number,
  z: number,
): THREE.BufferGeometry {
  const g = new THREE.PlaneGeometry(w, h);
  if (facing === "+x") g.rotateY(Math.PI / 2);
  else if (facing === "-x") g.rotateY(-Math.PI / 2);
  else if (facing === "-z") g.rotateY(Math.PI);
  return g.translate(x, y, z);
}

/** Tube along a smooth curve through points. */
export function tube(points: THREE.Vector3[], r: number, segments = 12, radial = 6): THREE.BufferGeometry {
  return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), segments, r, radial, false);
}
