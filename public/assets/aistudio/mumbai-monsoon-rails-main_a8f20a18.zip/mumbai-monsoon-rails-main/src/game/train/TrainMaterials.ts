import * as THREE from "three";
import type { CoachSpec, Livery } from "./TrainConfig";
import { displayAtlas, floorTexture, glowTexture, instrumentTexture, liveryTexture } from "./trainTextures";

/** Emissive strengths when a light group is switched on. */
export const LAMP_ON = {
  head: 3.2,
  tail: 2.6,
  tubes: 1.6,
  destination: 1.9,
  info: 1.3,
  instruments: 0.55,
} as const;

/**
 * One material per surface type for the whole rake, so every coach shares
 * them. Coaches differ only in geometry (number plates) and lamp roles.
 */
export function createTrainMaterials(livery: Livery, coaches: CoachSpec[], destination: { name: string; code: string }) {
  const textures: THREE.Texture[] = [];
  const tex = <T extends THREE.Texture>(t: T): T => {
    textures.push(t);
    return t;
  };
  const atlas = tex(displayAtlas(livery, coaches, destination));
  const std = (p: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial(p);

  const materials = {
    livery: std({ map: tex(liveryTexture(livery)), roughness: 0.42, metalness: 0.15 }),
    frontAccent: std({ color: livery.accent, roughness: 0.45, metalness: 0.1 }),
    roof: std({ vertexColors: true, roughness: 0.7, metalness: 0.35 }),
    steel: std({ vertexColors: true, roughness: 0.32, metalness: 0.85 }),
    dark: std({ vertexColors: true, roughness: 0.75, metalness: 0.35 }),
    glass: new THREE.MeshPhysicalMaterial({
      color: 0x263a40,
      roughness: 0.06,
      metalness: 0.1,
      transparent: true,
      opacity: 0.32,
      depthWrite: false,
      side: THREE.DoubleSide,
      envMapIntensity: 1.4,
    }),
    lining: std({ vertexColors: true, roughness: 0.78 }),
    floor: std({ map: tex(floorTexture()), roughness: 0.9 }),
    seats: std({ vertexColors: true, roughness: 0.5, metalness: 0.25 }),
    wheel: std({ color: 0x4b4744, roughness: 0.45, metalness: 0.85 }),
    bogie: std({ vertexColors: true, roughness: 0.68, metalness: 0.4 }),
    tubes: std({ color: 0xf6f3ea, emissive: 0xfff6e2, emissiveIntensity: LAMP_ON.tubes }),
    headLens: std({ color: 0xf6f2e6, emissive: 0xfff1d0, emissiveIntensity: LAMP_ON.head, roughness: 0.1 }),
    headOff: std({ color: 0x9aa0a4, roughness: 0.1, metalness: 0.6 }),
    tailLens: std({ color: 0x5a0d0d, emissive: 0xff2414, emissiveIntensity: LAMP_ON.tail, roughness: 0.2 }),
    tailOff: std({ color: 0x4a1212, roughness: 0.25 }),
    destination: std({ map: atlas, emissiveMap: atlas, emissive: 0xffffff, emissiveIntensity: LAMP_ON.destination, roughness: 0.4 }),
    info: std({ map: atlas, emissiveMap: atlas, emissive: 0xffffff, emissiveIntensity: LAMP_ON.info, roughness: 0.4 }),
    plates: std({ map: atlas, roughness: 0.5, metalness: 0.1 }),
    instruments: (() => {
      const t = tex(instrumentTexture());
      return std({ map: t, emissiveMap: t, emissive: 0xffffff, emissiveIntensity: LAMP_ON.instruments, roughness: 0.6 });
    })(),
    needle: std({ color: 0xff6a2b, emissive: 0xff5a1a, emissiveIntensity: 0.8 }),
    headGlow: new THREE.SpriteMaterial({
      map: tex(glowTexture()),
      color: 0xfff0d0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      transparent: true,
    }),
    tailGlow: new THREE.SpriteMaterial({
      map: textures[textures.length - 1] as THREE.Texture,
      color: 0xff3020,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      transparent: true,
    }),
  };

  return {
    ...materials,
    dispose() {
      Object.values(materials).forEach((m) => m.dispose());
      textures.forEach((t) => t.dispose());
    },
  };
}

export type TrainMaterials = ReturnType<typeof createTrainMaterials>;
