import { GAUGE } from "../world/layout";

/**
 * Mumbai suburban EMU dimensions in metres. Values follow the broad
 * proportions of the city's 3-phase EMU stock (≈20 m bodies, 3.66 m wide,
 * three double-leaf doorways per side, 952 mm wheels) without copying any
 * specific manufacturer's drawings.
 *
 * Coach-local axes: x across (+x = left when facing the cab), y up from the
 * rail head, z along the coach with the cab end at +z.
 */
export const COACH = {
  length: 20,
  /** Body-end to body-end gap between coupled coaches. */
  gap: 0.9,
  width: 3.66,
  /** Underside of the body shell. */
  solebarY: 1.02,
  floorY: 1.2,
  eaveY: 3.56,
  roofY: 3.9,
  /** Outer skin and inner lining thicknesses; doors slide in the gap between. */
  skin: 0.035,
  lining: 0.03,
  liningInset: 0.12,
  ceilingY: 3.4,
  ceilingCrownY: 3.66,
  /** Driving cab depth behind the front face, and nose added in front of the body. */
  cabLength: 2.3,
  nose: 0.32,
  door: { width: 1.3, height: 1.95, centres: [-6.4, 0, 6.4] as readonly number[] },
  window: { width: 1.04, pier: 0.3, sill: 2.14, top: 3.06 },
  bogieCentre: 7.3,
  wheelbase: 2.7,
  wheelRadius: 0.476,
  aisleHalf: 0.45,
} as const;

export const COACH_PITCH = COACH.length + COACH.gap;
export const HALF_LENGTH = COACH.length / 2;
export const FRONT_Z = HALF_LENGTH + COACH.nose;
/** Wheel tread centre, matching the rail centre line used by the world. */
export const WHEEL_X = GAUGE / 2 + 0.036;
/** Door leaf travel when fully open (each leaf slides by half the doorway). */
export const DOOR_TRAVEL = COACH.door.width / 2;
export const DOOR_OPEN_SECONDS = 2.2;

export type CoachRole = "driving" | "motor" | "trailer";

export interface CoachSpec {
  index: number;
  role: CoachRole;
  /** Driving coaches only: "lead" faces +z, "trail" is turned to face -z. */
  cab: "lead" | "trail" | null;
  pantograph: boolean;
  /** Painted unit number, e.g. "5101A". Fictional numbering. */
  number: string;
  marking: "first" | "ladies" | null;
  /** Centre of the coach along the train, front coach at 0. */
  z: number;
}

export interface TrainSpec {
  id: string;
  cars: number;
  airConditioned: boolean;
  /** First unit number painted on the coaches. */
  unitBase: number;
}

/** Units of three: a motor coach in the middle of each unit, driving trailers at the ends. */
export function coachRole(index: number, cars: number): CoachRole {
  if (index === 0 || index === cars - 1) return "driving";
  return index % 3 === 1 ? "motor" : "trailer";
}

export function buildConsist(spec: TrainSpec): CoachSpec[] {
  if (!Number.isInteger(spec.cars) || spec.cars < 3 || spec.cars % 3 !== 0) {
    throw new Error(`A rake must be a whole number of 3-car units, got ${spec.cars}`);
  }
  const coaches: CoachSpec[] = [];
  for (let index = 0; index < spec.cars; index++) {
    const role = coachRole(index, spec.cars);
    const unit = Math.floor(index / 3);
    const suffix = "ABC"[index % 3] ?? "A";
    let marking: CoachSpec["marking"] = null;
    if (index === 3 || index === spec.cars - 4) marking = "first";
    else if (index === 2 || index === spec.cars - 3) marking = "ladies";
    coaches.push({
      index,
      role,
      cab: role !== "driving" ? null : index === 0 ? "lead" : "trail",
      pantograph: role === "motor",
      number: `${spec.unitBase + unit}${suffix}`,
      marking,
      z: -index * COACH_PITCH,
    });
  }
  return coaches;
}

/** Front and rear extremes of the rake along z, nose to nose. */
export function trainExtent(cars: number): { front: number; rear: number; length: number } {
  const front = FRONT_Z;
  const rear = -(cars - 1) * COACH_PITCH - FRONT_Z;
  return { front, rear, length: front - rear };
}

/** Wheelsets per coach (two bogies, two axles each). */
export const AXLES_PER_COACH = 4;

/* ------------------------------------------------------------------ */
/* Liveries                                                            */
/* ------------------------------------------------------------------ */

export type LiveryId = "western" | "central" | "harbour";

export interface Livery {
  id: LiveryId;
  name: string;
  /** Body base colour. */
  body: string;
  /** Main belt and cant-rail bands. */
  band: string;
  /** Thin pinstripe and front warning panel. */
  accent: string;
  skirt: string;
  roof: string;
  destination: string;
  /** "S" slow / "F" fast service letter shown on the indicator. */
  service: "S" | "F";
  /** Stations shown on the interior route board, from the city end. */
  stations: string[];
}

/**
 * Stylised liveries inspired by each line's colours. They are not a
 * reproduction of any specific railway fleet's paint scheme.
 */
export const LIVERIES: Readonly<Record<LiveryId, Livery>> = {
  western: {
    id: "western",
    name: "Western Line",
    body: "#ece6d8",
    band: "#55367f",
    accent: "#f0b21a",
    skirt: "#34383e",
    roof: "#8d9195",
    destination: "CHURCHGATE",
    service: "F",
    stations: ["Churchgate", "Mumbai Central", "Dadar", "Bandra", "Andheri", "Goregaon", "Malad", "Borivali", "Bhayandar", "Vasai Road", "Virar"],
  },
  central: {
    id: "central",
    name: "Central Line",
    body: "#f0eee8",
    band: "#8a2231",
    accent: "#e9a41d",
    skirt: "#36363a",
    roof: "#909292",
    destination: "CSMT",
    service: "S",
    stations: ["CSMT", "Byculla", "Parel", "Dadar", "Kurla", "Ghatkopar", "Vikhroli", "Mulund", "Thane", "Dombivli", "Kalyan"],
  },
  harbour: {
    id: "harbour",
    name: "Harbour Line",
    body: "#edf0ee",
    band: "#1d6a72",
    accent: "#d9c23a",
    skirt: "#33383a",
    roof: "#8b9393",
    destination: "PANVEL",
    service: "S",
    stations: ["CSMT", "Sandhurst Rd", "Wadala Rd", "Kurla", "Chembur", "Mankhurd", "Vashi", "Nerul", "Belapur", "Kharghar", "Panvel"],
  },
};

export const LIVERY_IDS: readonly LiveryId[] = ["western", "central", "harbour"];

/** Default livery for a selected route (the Trans-Harbour link shares Harbour stock here). */
export function liveryForRoute(routeId: string): LiveryId {
  if (routeId === "western" || routeId === "central" || routeId === "harbour") return routeId;
  return "harbour";
}

/** Text on the front and side destination indicators. */
export function destinationText(livery: Livery, cars: number): { name: string; code: string } {
  return { name: livery.destination, code: `${livery.service} ${cars}` };
}
