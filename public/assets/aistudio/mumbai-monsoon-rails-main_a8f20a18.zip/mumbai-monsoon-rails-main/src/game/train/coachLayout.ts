import { COACH, FRONT_Z, HALF_LENGTH, type CoachRole } from "./TrainConfig";

export interface Span {
  z0: number;
  z1: number;
}

export interface CoachLayout {
  role: CoachRole;
  /** Body extent along z (driving coaches add the nose at +z). */
  zBack: number;
  zFront: number;
  /** Passenger doorway centres. */
  doors: readonly number[];
  /** Passenger window openings (same on both sides). */
  windows: Span[];
  /** Saloon stretches between doorways and ends, used for seating. */
  bays: Span[];
  /** Driving coaches: cab partition position and cab side openings. */
  cabStart: number | null;
  cabDoor: Span | null;
  cabWindow: Span | null;
}

const DOOR_CLEAR = 0.25;
const END_CLEAR = 0.45;

/** Evenly spaced, centred windows that fit a stretch of wall. */
export function windowsIn(span: Span): Span[] {
  const { width, pier } = COACH.window;
  const length = span.z1 - span.z0;
  const n = Math.floor((length + pier) / (width + pier));
  if (n <= 0) return [];
  const total = n * width + (n - 1) * pier;
  const start = (span.z0 + span.z1) / 2 - total / 2;
  return Array.from({ length: n }, (_, i) => ({
    z0: start + i * (width + pier),
    z1: start + i * (width + pier) + width,
  }));
}

export function coachLayout(role: CoachRole): CoachLayout {
  const doors = COACH.door.centres;
  const half = COACH.door.width / 2;
  const driving = role === "driving";
  const cabStart = driving ? HALF_LENGTH - COACH.cabLength : null;
  const saloonEnd = cabStart ?? HALF_LENGTH;
  const edges: number[] = [-HALF_LENGTH + END_CLEAR];
  doors.forEach((d) => edges.push(d - half - DOOR_CLEAR, d + half + DOOR_CLEAR));
  edges.push(saloonEnd - (driving ? 0.15 : END_CLEAR));
  const wallSpans: Span[] = [];
  for (let i = 0; i < edges.length; i += 2) {
    const z0 = edges[i] as number;
    const z1 = edges[i + 1] as number;
    if (z1 - z0 > 0.2) wallSpans.push({ z0, z1 });
  }
  const bays: Span[] = [];
  const bayEdges = [-HALF_LENGTH + 0.15, ...doors.flatMap((d) => [d - half - 0.12, d + half + 0.12]), saloonEnd - 0.15];
  for (let i = 0; i < bayEdges.length; i += 2) {
    const z0 = bayEdges[i] as number;
    const z1 = bayEdges[i + 1] as number;
    if (z1 - z0 > 0.5) bays.push({ z0, z1 });
  }
  return {
    role,
    zBack: -HALF_LENGTH,
    zFront: driving ? FRONT_Z : HALF_LENGTH,
    doors,
    windows: wallSpans.flatMap(windowsIn),
    bays,
    cabStart,
    cabDoor: driving ? { z0: 7.95, z1: 8.6 } : null,
    cabWindow: driving ? { z0: 8.85, z1: 9.8 } : null,
  };
}
