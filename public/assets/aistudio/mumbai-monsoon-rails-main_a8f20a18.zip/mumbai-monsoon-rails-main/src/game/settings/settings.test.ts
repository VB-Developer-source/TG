import { describe, expect, it } from "vitest";
import type { KeyValueStorage } from "../core/PersistentStore";
import {
  DEFAULT_SETTINGS,
  SETTINGS_STORAGE_KEY,
  createSettingsStore,
  sanitizeSettings,
} from "./settings";
import { createSelectionStore, SELECTION_STORAGE_KEY } from "../data/catalog";
import { nextPixelRatio } from "../core/adaptive";

function memoryStorage(initial: Record<string, string> = {}): KeyValueStorage & { data: Record<string, string> } {
  const data = { ...initial };
  return {
    data,
    getItem: (k) => data[k] ?? null,
    setItem: (k, v) => {
      data[k] = v;
    },
    removeItem: (k) => {
      delete data[k];
    },
  };
}

describe("settings", () => {
  it("saves a change to storage and reads it back on the next load", () => {
    const storage = memoryStorage();
    createSettingsStore(storage).update({ quality: "low", shadows: false, sound: false });
    const reloaded = createSettingsStore(storage).get();
    expect(reloaded).toMatchObject({ quality: "low", shadows: false, sound: false });
  });

  it("reset restores defaults and clears the saved value", () => {
    const storage = memoryStorage();
    const store = createSettingsStore(storage);
    store.update({ quality: "high", cameraSensitivity: 1.8 });
    store.reset();
    expect(store.get()).toEqual(DEFAULT_SETTINGS);
    expect(storage.data[SETTINGS_STORAGE_KEY]).toBeUndefined();
  });

  it("clamps camera sensitivity to 0.2–2.0", () => {
    expect(sanitizeSettings({ cameraSensitivity: 9 }).cameraSensitivity).toBe(2);
    expect(sanitizeSettings({ cameraSensitivity: -1 }).cameraSensitivity).toBe(0.2);
  });

  it("falls back to defaults for corrupted saved data", () => {
    const storage = memoryStorage({ [SETTINGS_STORAGE_KEY]: "{not json" });
    expect(createSettingsStore(storage).get()).toEqual(DEFAULT_SETTINGS);
    expect(sanitizeSettings({ quality: "ultra" }).quality).toBe(DEFAULT_SETTINGS.quality);
  });

  it("works without storage (private browsing)", () => {
    const store = createSettingsStore(null);
    store.update({ sound: false });
    expect(store.get().sound).toBe(false);
  });
});

describe("route and train selection", () => {
  it("persists the chosen route and rejects unknown ids", () => {
    const storage = memoryStorage();
    createSelectionStore(storage).update({ routeId: "harbour" });
    expect(createSelectionStore(storage).get().routeId).toBe("harbour");
    const bad = memoryStorage({ [SELECTION_STORAGE_KEY]: JSON.stringify({ routeId: "nowhere" }) });
    expect(createSelectionStore(bad).get().routeId).toBe("western");
  });
});

describe("adaptive resolution", () => {
  it("drops resolution by 0.25 when frames run slow and never below the minimum", () => {
    expect(nextPixelRatio(1.5, 30, 0.75, 1.5)).toBe(1.25);
    expect(nextPixelRatio(0.75, 40, 0.75, 1.5)).toBe(0.75);
  });

  it("raises resolution when there is headroom, capped at the maximum", () => {
    expect(nextPixelRatio(1, 16.7, 0.75, 1.5)).toBe(1.25);
    expect(nextPixelRatio(1.5, 16.7, 0.75, 1.5)).toBe(1.5);
  });
});
