import { FreeCameraMode, type VirtualMove } from "../camera/FreeCameraMode";
import type { GameContext } from "../core/Game";
import type { GameScene } from "./SceneManager";

/**
 * Free camera walk-around of the station. Driving, trains and routes plug in
 * here in later sections.
 */
export class ExploreScene implements GameScene {
  readonly name = "explore" as const;
  readonly rendersWorld = true;
  private freeCamera: FreeCameraMode | null = null;

  constructor(private readonly ctx: GameContext) {}

  init(): void {
    this.freeCamera = new FreeCameraMode(
      this.ctx.renderer.canvas,
      () => this.ctx.settings.get().cameraSensitivity,
      this.ctx.cameras.limits,
    );
    this.ctx.cameras.register(this.freeCamera);
  }

  enter(): void {
    this.ctx.cameras.setMode("free");
  }

  setVirtualMove(move: VirtualMove): void {
    this.freeCamera?.setVirtualMove(move);
  }

  update(): void {}

  exit(): void {
    this.freeCamera?.setVirtualMove({ forward: 0, right: 0, up: 0 });
  }

  dispose(): void {
    this.freeCamera = null;
  }
}
