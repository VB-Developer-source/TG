import { useCallback, useEffect, useRef, useState } from "react";
import { Game } from "../core/Game";
import { getBrowserStorage } from "../core/PersistentStore";
import { createSelectionStore, type SelectionStore } from "../data/catalog";
import { createSettingsStore, type SettingsStore } from "../settings/settings";
import { ErrorOverlay } from "./ErrorOverlay";
import { ExploreHud } from "./ExploreHud";
import { LoadingScreen } from "./LoadingScreen";
import { MainMenu, type MenuView } from "./MainMenu";
import { useObservable } from "./hooks";

interface Stores {
  settings: SettingsStore;
  selection: SelectionStore;
}

/** Mounts the engine into a full-screen container and layers the UI over it. */
export function GameApp() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [stores] = useState<Stores>(() => {
    const storage = getBrowserStorage();
    return { settings: createSettingsStore(storage), selection: createSelectionStore(storage) };
  });
  const [game, setGame] = useState<Game | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const instance = new Game(container, stores.settings);
    setGame(instance);
    void instance.start();
    const unlockAudio = () => instance.audio.unlock();
    window.addEventListener("pointerdown", unlockAudio);
    window.addEventListener("keydown", unlockAudio);
    return () => {
      window.removeEventListener("pointerdown", unlockAudio);
      window.removeEventListener("keydown", unlockAudio);
      instance.dispose();
      setGame(null);
    };
  }, [stores]);

  return (
    <div className="game-root">
      <div ref={containerRef} className="game-viewport" />
      {game && <GameOverlay game={game} stores={stores} />}
    </div>
  );
}

function GameOverlay({ game, stores }: { game: Game; stores: Stores }) {
  const loading = useObservable(game.loading);
  const scene = useObservable(game.scene);
  const error = useObservable(game.error);
  const stats = useObservable(game.stats);
  const [view, setView] = useState<MenuView>("main");
  const click = useCallback(() => game.audio.click(), [game]);
  const exitExplore = useCallback(() => {
    click();
    setView("main");
    game.goTo("menu");
  }, [game, click]);

  const loaderVisible = !(loading.done && (scene === "menu" || scene === "explore"));

  return (
    <>
      {scene === "menu" && (
        <MainMenu
          view={view}
          onNavigate={setView}
          onPlay={() => game.goTo("explore")}
          onInteract={click}
          settings={stores.settings}
          selection={stores.selection}
          stats={stats}
        />
      )}
      {scene === "explore" && <ExploreHud stats={stats} onExit={exitExplore} onMove={(m) => game.setVirtualMove(m)} />}
      <LoadingScreen progress={loading} visible={loaderVisible && !error?.fatal} />
      {error && <ErrorOverlay error={error} onDismiss={() => game.error.set(null)} />}
    </>
  );
}
