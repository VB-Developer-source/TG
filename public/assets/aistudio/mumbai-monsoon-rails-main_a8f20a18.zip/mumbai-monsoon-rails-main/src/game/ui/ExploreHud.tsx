import { useEffect, useRef, useState, type ReactNode } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, ChevronsDown, ChevronsUp, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { VirtualMove } from "../camera/FreeCameraMode";
import type { FrameStats } from "../core/Game";
import { useEscape } from "./hooks";

interface ExploreHudProps {
  stats: FrameStats;
  onExit: () => void;
  onMove: (move: VirtualMove) => void;
}

type Axis = keyof VirtualMove;

function useCoarsePointer(): boolean {
  const [coarse, setCoarse] = useState(false);
  useEffect(() => {
    const query = window.matchMedia("(pointer: coarse)");
    const sync = () => setCoarse(query.matches);
    sync();
    query.addEventListener("change", sync);
    return () => query.removeEventListener("change", sync);
  }, []);
  return coarse;
}

export function ExploreHud({ stats, onExit, onMove }: ExploreHudProps) {
  useEscape(onExit);
  const coarse = useCoarsePointer();
  const move = useRef<VirtualMove>({ forward: 0, right: 0, up: 0 });

  const press = (axis: Axis, value: number) => {
    move.current = { ...move.current, [axis]: value };
    onMove(move.current);
  };

  const Pad = ({ axis, value, label, children }: { axis: Axis; value: number; label: string; children: ReactNode }) => (
    <button
      type="button"
      className="dpad-button"
      aria-label={label}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        press(axis, value);
      }}
      onPointerUp={() => press(axis, 0)}
      onPointerCancel={() => press(axis, 0)}
    >
      {children}
    </button>
  );

  return (
    <div className="pointer-events-none absolute inset-0 z-20">
      <div className="fade-up absolute left-4 right-4 top-4 flex items-start justify-between gap-3 sm:left-6 sm:right-6 sm:top-6">
        <div className="flex flex-col gap-2">
          <span className="hud-chip">
            <span className="signal-lamp" aria-hidden /> Free camera · Dadar
          </span>
          <span className="hud-chip text-muted-foreground">Train driving arrives in a later build</span>
        </div>
        <Button variant="rail" className="pointer-events-auto" onClick={onExit}>
          <Home /> Menu <span className="kbd ml-1 hidden sm:inline-flex">Esc</span>
        </Button>
      </div>

      {!coarse && (
        <div className="fade-up absolute bottom-6 left-6 hidden flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground sm:flex">
          <span className="flex items-center gap-1.5">
            <span className="kbd">W</span>
            <span className="kbd">A</span>
            <span className="kbd">S</span>
            <span className="kbd">D</span> move
          </span>
          <span className="flex items-center gap-1.5">
            <span className="kbd">Q</span>
            <span className="kbd">E</span> height
          </span>
          <span className="flex items-center gap-1.5">
            <span className="kbd">Shift</span> fast
          </span>
          <span className="flex items-center gap-1.5">
            <span className="kbd">Drag</span> look
          </span>
          <span className="flex items-center gap-1.5">
            <span className="kbd">Wheel</span> dolly
          </span>
        </div>
      )}

      {coarse && (
        <div className="pointer-events-auto absolute bottom-6 left-4 grid grid-cols-3 gap-2">
          <span />
          <Pad axis="forward" value={1} label="Move forward">
            <ArrowUp />
          </Pad>
          <span />
          <Pad axis="right" value={-1} label="Move left">
            <ArrowLeft />
          </Pad>
          <Pad axis="forward" value={-1} label="Move back">
            <ArrowDown />
          </Pad>
          <Pad axis="right" value={1} label="Move right">
            <ArrowRight />
          </Pad>
        </div>
      )}
      {coarse && (
        <div className="pointer-events-auto absolute bottom-6 right-4 flex flex-col gap-2">
          <Pad axis="up" value={1} label="Move up">
            <ChevronsUp />
          </Pad>
          <Pad axis="up" value={-1} label="Move down">
            <ChevronsDown />
          </Pad>
        </div>
      )}

      <div
        className={`absolute bottom-6 flex flex-col items-end gap-2 ${coarse ? "right-20" : "right-6"}`}
        aria-label="Camera telemetry"
      >
        <span className="hud-chip tabular-nums">
          X {stats.position[0].toFixed(1)} · Y {stats.position[1].toFixed(1)} · Z {stats.position[2].toFixed(1)}
        </span>
        <span className="hud-chip tabular-nums">
          {stats.fps || "--"} fps · {stats.pixelRatio.toFixed(2)}× res
        </span>
      </div>
    </div>
  );
}
