import { createFileRoute } from "@tanstack/react-router";
import { GameApp } from "@/game/ui/GameApp";

export const Route = createFileRoute("/")({
  // WebGL and browser APIs only exist on the client.
  ssr: false,
  head: () => ({
    meta: [
      { title: "Mumbai Local Train Simulator 3D" },
      {
        name: "description",
        content:
          "A 3D browser simulator of Mumbai's suburban railway. Explore Dadar station's tracks, platform and overhead wires.",
      },
      { property: "og:title", content: "Mumbai Local Train Simulator 3D" },
      {
        property: "og:description",
        content: "Experience the lifeline of Mumbai: a 3D suburban railway simulator in your browser.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GameApp,
});
