# Roadmap

## Section 01 — Foundation (done)
- [x] Dadar station world, menus, free camera, settings, loading screen
- [x] Browser check of the menu scene

## Section 02 — Rolling stock + audio
- [ ] Train config: dimensions, consist (12/15 cars), liveries (Western / Central / Harbour)
- [ ] Procedural EMU: body shell, cab front, windows, sliding doors, roof, underbody, couplers
- [ ] Bogies, wheelsets (separate rotatable objects), pantographs, brake gear
- [ ] Interior: seats, poles, rails, straps, fans, lights, partitions, route boards; driver cab with desk and gauges
- [ ] Train lights: headlights, tail markers, interior, destination display, on/off
- [ ] Audio system: buses, settings store, train / environment / UI sounds, autoplay handling
- [ ] Audio settings UI with volume sliders, mute, previews, persistence
- [ ] Carshed train preview scene: orbit camera, views (front/side/rear/interior/cab), lights, audio preview
- [ ] Hook preview into Train Select
- [ ] Tests for config, audio settings and sound model
- [ ] Browser verification + screenshots, README, testing report
